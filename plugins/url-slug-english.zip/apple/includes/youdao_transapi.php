<?php
/** 
* Send a GET requst using cURL 
* @param string $url to request 
* @return string 
*/ 

function youdao_translate( $words ){
    $keyfrom = get_option( 'youdao-keyfrom', false );
    $api_key = get_option( 'youdao-api-key', false );

    if ( empty( $keyfrom ) && empty( $api_key ) ) {
        $keyfrom = 'zengxiaoluan';
        $api_key = '399184121';
    }

    $url = 'http://fanyi.youdao.com/openapi.do?keyfrom=' . $keyfrom . '&key=' . $api_key . '&type=data&doctype=json&version=1.1&q=' . urlencode($words) ;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_URL, $url);
    $results = json_decode( curl_exec($ch) ) ;

    return isset( $results->translation[0] ) ? $results->translation[0] : null;
}

