<h3>Turn your Wordpress categories to the next level with ultra fast organization mode. Manage categories in an <strong>explorer-like tree view and create a custom category order.</strong></h3>
<p><strong>RCM</strong> (Real Categories Management) allows you to organize all your wordpress categories within the main screen - easy and flexible.</p>
<p>Use your mouse (or touch) to <strong>drag and drop</strong> your posts. Create, rename, delete or reorder your categories. It works fine with every <strong>custom post type</strong> and <strong>WooCommerce products</strong>. Just install this plugin and it works fine with all your written posts. It also <strong>supports multisite</strong>.</p>
<p>If you buy, you get: <strong>Forever FREE updates and high quality and fast support.</strong></p>
<h3>Table of contents</h3>
<ul>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__what-s-new">What's new?</a></li>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__introduction">Introduction</a></li>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__screenshots">Screenshots</a></li>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__features">Features</a></li>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__faq">FAQ</a></li>
	<li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__installation-and-compatibility">Installation and Compatibility</a></li>
  <li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__we-guarantee-high-quality-products-and-support">Reviews</a></li>
  <li><a href="https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393#item-description__updates">Changelog and Updates</a></li>
</ul>
<h3>What's new?</h3>
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/new-3-2.jpg" />
<a href="https://matthias-web.com/newsletter-signup"><img src="https://matthias-web.com/wp-content/uploads/Envato/newsletter.gif" /></a>
<h3>Introduction</h3>
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/testimonal.jpg" />
<a href="https://try.matthias-web.com/?product=RCM"><img src="https://matthias-web.com/wp-content/uploads/Envato/try-demo.gif" /></a>
<a href="https://matthias-web.com/wp-content/uploads/Envato/support.jpg" /></a>
<h3>Screenshots</h3>
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/move-append.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-move-append.gif" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/control.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-control.gif" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/cat-order.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-cat-order.gif" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/woocommerce.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-woocommerce.gif" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/cpt.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/tree-page-reload.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-cpt.gif" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/pagination.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/feature-pagination.gif" />
<h3>Features</h3>
<ul>
   <li><strong>WordPress 5.0 / Gutenberg</strong> ready</li>
   <li><strong>Flexible view</strong> of your categories structure</li>
   <li><strong>Drag and drop</strong> your posts</li>
   <li>Works fine with <strong>WooCommerce products and product attributes</strong></li>
   <li>Just install and it works with your <strong>current categories</strong></li>
   <li>Move or <strong>append</strong> to category</li>
   <li>Supports <strong>custom post types</strong></li>
   <li>Supports multiple <strong>taxonomies and WooCommerce product attributes</strong></li>
   <li><strong>No annoying page reload</strong> while switching the content (pagination, category switch, taxonomy switch) - it works like <strong>infinite scroll</strong> for your WP List tables</li>
   <li>Full control for your folders in one toolbar (create, rename, delete, rearrange) </li>
   <li><strong>Custom term order</strong> for your front end order (drag & drop)</li>
   <li>Compatible with touch devices</li>
   <li>Supports multisite</li>
   <li>6 months support Included</li>
   <li>Forever free updates</li>
</ul>
<h3>FAQ</h3>
<a href="https://codecanyon.net/item/wp-real-categories-library-category-organisation-tree-view/13580393/comments">Question? <strong>Write a comment here</strong></a><br /><br /> <strong>Does it work with WooCommerce?</strong> Yes. <br /><br />
<strong>What should i do if the plugin does not work correct after version update?</strong> Please clear the browser cache by reloading the page (CTRL + R).<br /><br /> Extended license doesn’t cover multiple uses. You need to purchase a regular or an extended license for every site.<br/><br/>
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/v3/convinced.jpg" />
<a href="https://goo.gl/N8lkGb">
   <img src="https://matthias-web.com/wp-content/uploads/Envato/add-cart.gif" />
</a><br />
<h3>Installation and Compatibility</h3>
If you buy this item you will become an introduction how to install the plugin.
<p>The Real Categories Management plugin is compatible with <strong>all wordpress themes and plugins</strong>. For example: You bought a theme on themeforest like the <strong>X Theme, Avada, Bridge, Salient, Be Theme or Enfold</strong>? No Problem! It also works great with <strong>Visual Composer, Justified Image Grid and Slider Revolution</strong>.</p>
<h3>We guarantee high quality products and support!</h3>
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/Reviews/review1.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/Reviews/review2.jpg" />
<img src="https://matthias-web.com/wp-content/uploads/Envato/RCM/Reviews/review3.jpg" />
<br/><br/>
<h3>Updates</h3>
<code>07 May 2019 - Version 3.2.3
- Added "title" attribute to tree node for accessibility
- (developers only) Updated to latest AIOT version

19 March 2019 - Version 3.2.2
- Added button to expand/collapse all node items
- Fixed bug with style/script dependencies
- Fixed bug with missing animations
- Improved performance: Loading a tree with 10,000 nodes in 1s (the old way in 30s)

10 December 2018 - Version 3.2.1
- Added notice to the tree if the product is not yet registered

27 October 2018 - Version 3.2.0
- Added auto update functionality
- Fixed bug with new created folders and droppable posts
- (developers only) Fixed bug with WPML API requests

17 August 2018 - Version 3.1.1 HOTFIX
- Fixed bug with relocating categories to a category with no childs yet
 
05 August 2018 - Version 3.1.0
- Improved the custom order performance
- Improved the way of handling custom order
- Fixed bug with mass categories
- Fixed bug with "Plain" permalink structure
- Fixed bug with collapsable/expandable folders
 
20 July 2018 - Version 3.0.6
- Improved error handling with plugins like Clearfy
- Fixed bug with "&" in category names
- Fixed bug with PHP 5.3
- Fixed bug with non-SSL API root urls
- Fixed bug with pagination in list mode after switching folder
- (developers only) Fixed bug with Gutenberg 3.1.x (https://git.io/f4SXU)

15 June 2018 - Version 3.0.5
- Added compatibility with WP Dark Mode plugin
- Added help message if WP REST API is not reachable through HTTP verbs
- Fixed bug with scroll container in media modal in IE/Edge/Firefox
- (developers only) Use global WP REST API parameters instead of DELETE / PUT

4 June 2018 - Version 3.0.4
- Fixed bug with spinning loader when permalink structure is "Plain"
- Fixed bug with german translation
- Fixed bug with IE11/Edge browser
 
17 May 2018 - Version 3.0.3
- Fixed bug with WPML and fetching a tree from another language within admin dashboard

08 May 2018 - Version 3.0.2
- Improved performance
- Fixed bug with switching from category to "All posts"
- (developers only) Added Mobx State Tree for frontend state management

09 March 2018 - Version 3.0.1
- Fixed bug with mobile devices

02 March 2018 - Version 3.0.0
- Complete code rewrite
- ... Same functionality with improved performance
- ... with an eye on smooth user interface and experience
- The plugin is now available in the following languages: English, German
- Fixed bug with WooCommerce 3.3.x product attributes
- (developers only) Sidebar is now fully written in ReactJS v16
- (developers only) The plugin is now bundled with webpack v3
- (developers only) Minimum of PHP 5.3 required now (in each update you'll find v2.4 for PHP 5.0+ compatibility)
- (developers only) Minimum of WordPress 4.4 required now (in each update you'll find v2.4 for 4.0+ compatibility)
- (developers only) PHP Classes modernized with autoloading and namespaces
- (developers only) WP REST API v2 for API programming, no longer use admin-ajax.php for your CRUD operations
- (developers only) Implemented cachebuster to avoid cache problems
- (developers only) ApiGen for PHP Documentation
- (developers only) JSDoc for JavaScript Documentation
- (developers only) apiDoc for API Documentation
- (developers only) WP HookDoc for Filters & Actions Documentation
- (developers only) Custom filters and actions which affected the tree ouput are now removed, you have to do this in JS now
- (developers only) All JavaScript events / hooks are removed now - contact me so I can implement for you

16 January 2018 - Version 2.4
- Added support for WooCommerce attributes (through an option)
- Improved the tax switcher (when multiple category types are available)

24 November 2017 - Version 2.3.2
- Fixed bug with hidden sidebar without resized before
- (developers only) Added filter to hide category try for specific taxonomies (RCL/Available)

31 October 2017 - Version 2.3.1 HOTFIX
- Fixed bug after creating a new post the nodes are not clickable
- Fixed bug when switching taxonomy when fast mode is deactivated

28 October 2017 - Version 2.3
- Added ability to expand/collapse the complete sidebar by doubleclick the resize button
- Fixed bug with WooCommerce 3.x
- Fixed bug with touch devices (no dropdown was touchable)
- Fixed bug with ESC key in rename mode
- Fixed bug with creating a new folder and switch back to previous
- Fixed bug with taxonomy switcher (especially WooCommerce products)
- (developers only) Improved the save of localStorage items within one row per tree instance

22 September 2017 - Version 2.2.1
- Improved the tax switcher when more than two taxonomies are available
- Fixed bug when switching to an taxonomy with no categories
- (developers only) Added new filter to disable RCL sorting mechanism

24 June 2017 - Version 2.2
- Added full compatibility with WordPress 4.8
- Added ESC to close the rename category action
- Added F2 handler to rename a category
- Added double click event to open category hierarchy
- Added search input field for categories
- Fixed bug with some browsers when local storage is disabled

24 March 2017 - Version 2.1.1
- Added https://matthias-web.com as author url
- Improved the way of rearrange mode, the folders gets expand after 700ms of hover
- Fixed bug with > 600 categories
- Fixed bug with styles and scripts
- Fixed bug with rearrange

24 November 2016 - Version 2.1
- Added new version of AIO tree view (1.3.1)
- Added the MatthiasWeb promotion dialog
- Added responsivness
- Improved performance with lazy loading of categories
- Improved changelog
- (developers only) Use rootParentId in jQuery AIO tree
- (developers only) Fixed bug with jQuery AIO tree version when RML is enabled

09. September 2016 - Version 2.0.2 HOTFIX
- (developers only) Conflict with jQuery.allInOneTree

02. September 2016 - Version 2.0.1
- Added minified scripts and styles
- Fixed capability bug while logged out
- (developers only) Added Javascript polyfill's to avoid browser incompatibility
- (developers only) Fixed bug for crashed safari browser
- (developers only) Fixed bug with boolval function

08 August 2016 - Version 2.0
- Added more userfriendly toolbar (ported from RML)
- Added fixed header
- Added "fast mode" for switching between taxonomies without page reload
- Added "fast mode" for switching between categories without page reload
- Added "fast mode" for switching between pages without page reload
- Added taxonomy to pages
- Added custom order for taxonomies
- Added new advertisment system for MatthiasWeb
- (developers only) Complete recode of PHP and Javascript

20 January 2016 - Version 1.1.1
- added facebook advert on plugin activation
- fixed count of categories

28 November 2015 - Version 1.1
- fixed conditional tag to create / sort items
- fixed hierarchical read of categories
- fixed append method with CTRL - now tap and hold any key to append

13 November 2015 - Version 1.0.2
- removed unnecessary code
- fixed jquery conflict

10 November 2015 - Version 1.0.1
- fixed javascript error for firefox, ie and opera

08 November 2015 - Version 1.0
- initial review</code>
<br/><br/>
<a href="http://s05.flagcounter.com/more/MKM"><img src="http://s05.flagcounter.com/mini/MKM/bg_FFFFFF/txt_000000/border_CCCCCC/flags_0/"></a>
