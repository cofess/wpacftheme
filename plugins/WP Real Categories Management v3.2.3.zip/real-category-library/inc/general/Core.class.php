<?php
namespace MatthiasWeb\RealCategoryLibrary\general;
use MatthiasWeb\RealCategoryLibrary\base;
use MatthiasWeb\RealCategoryLibrary\rest;
use MatthiasWeb\RealCategoryLibrary\options;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

// Include files, where autoloading is not possible, yet
require_once(RCL_INC . 'base/Core.class.php');

/**
 * Singleton core class which handles the main system for plugin. It includes
 * registering of the autoloader, all hooks (actions & filters) (see base\Core class).
 */
class Core extends base\Core {
    
    const TERMS_PRIORITY = 9999999;
    
    /**
     * Singleton instance.
     */
    private static $me;
    
    /**
     * The taxonomy tree.
     * 
     * @see general\TaxTree
     */
    private $taxTree = null;
    
    /**
     * The main service.
     * 
     * @see rest\Service
     */
    private $service;
    
    /**
     * The tax order.
     * 
     * @see TaxOrder
     */
    private $taxOrder;
    
    /**
     * The screen settings.
     * 
     * @see options\ScreenSettings
     */
    private $screenSettings;
    
    /**
     * The WooCommerce handler.
     * 
     * @see WooCommerce
     */
    private $wooCommerce;
    
    /**
     * @see https://github.com/Capevace/wordpress-plugin-updater
     */
    private $updater;
    
    /**
     * Application core constructor.
     */
    protected function __construct() {
        parent::__construct();
        
        // Load no-namespace API functions
        foreach (array('general') as $apiInclude) {
            require_once(RCL_PATH . '/inc/api/' . $apiInclude . '.php');
        }
        
        $this->getUpdater(); // Initially load the updater
        $this->screenSettings = new options\ScreenSettings();
        $this->wooCommerce = new WooCommerce();
        add_action('plugins_loaded', array($this, 'updateDbCheck'));
        add_action('init', array(new PageCategory(), 'register_page_cat'), 99999);
        add_action('init', array($this->getWooCommerce(), 'init'), 2);
        add_filter('check_admin_referer', array($this->getScreenSettings(), 'check_admin_referer'), 10, 2);
    }
    
    /**
     * The init function is fired even the init hook of WordPress. If possible
     * it should register all hooks to have them in one place.
     */
    public function init() {
        $this->service = new rest\Service();
        $this->taxOrder = new TaxOrder();
        $comp = new Comp();
        
        // Register all your hooks here
        add_action('rest_api_init', array($this->getService(), 'rest_api_init'));
        add_action('rest_api_init', array(new rest\Term(), 'rest_api_init'));
        add_action('rest_api_init', array(new rest\Post(), 'rest_api_init'));
        add_action('admin_enqueue_scripts', array($this->getAssets(), 'admin_enqueue_scripts'));
        add_action('created_term', array($this->getTaxOrder(), 'created_term'), 10, 3);

        add_filter('screen_settings', array($this->getScreenSettings(), 'screen_settings'), 999, 2);
        add_filter('get_terms_orderby', array($this->getTaxOrder(), 'get_terms_orderby'), self::TERMS_PRIORITY, 2);
        add_filter('wp_get_object_terms', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY, 3);
        add_filter('get_the_terms', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY, 3);
        add_filter('get_terms', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY, 3);
        add_filter('tag_cloud_sort', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY, 3);
        add_filter('acf/format_value_for_api', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY);
        add_filter('get_the_categories', array($this->getTaxOrder(), 'wp_get_object_terms'), self::TERMS_PRIORITY, 3);
        add_filter('woocommerce_products_general_settings', array($this->getWooCommerce(), 'woocommerce_products_general_settings'));
        add_filter('RCL/Localize', array($comp, 'localize_wpml'));
        
        // Show plugin notice
        if (!$this->getUpdater()->isActivated()) {
            add_action('after_plugin_row_' . plugin_basename(RCL_FILE), array($this, 'after_plugin_row'), 10, 2 );
        }
    }
    
    /**
     * Get the service.
     * 
     * @returns rest\Service
     */
    public function getService() {
        return $this->service;
    }
    
    /**
     * Get the tax order.
     * 
     * @returns TaxOrder
     */
    public function getTaxOrder() {
        return $this->taxOrder;
    }
    
    /**
     * Get the screen settings.
     * 
     * @returns options\ScreenSettings
     */
    public function getScreenSettings() {
        return $this->screenSettings;
    }
    
    /**
     * Get the WooCommerce handler.
     * 
     * @returns WooCommerce
     */
    public function getWooCommerce() {
        return $this->wooCommerce;
    }
    
    /**
     * Get the current taxonomy tree.
     * 
     * @returns general\TaxTree
     */
    public function getDefaultTaxTree() {
        return $this->taxTree === null ? $this->taxTree = new TaxTree() : $this->taxTree;
    }
    
    /**
     * Get the updater instance.
     * 
     * @see https://github.com/matzeeable/wordpress-plugin-updater
     */
    public function getUpdater() {
        if ($this->updater === null) {
            $this->updater = \MatthiasWeb\WPU\V4\WPLSController::initClient('https://license.matthias-web.com/', array(
                'name'      => 'WP Real Categories Management',
                'version'   => RCL_VERSION,
                'path'      => RCL_FILE,
                'slug'      => 'real-category-library'
            ));
        }
        return $this->updater;
    }
    
    /**
     * Set and/or get the value if the license notice is dismissed.
     * 
     * @param boolean $set
     * @returns boolean
     */
    public function isLicenseNoticeDismissed($set = null) {
        $transient = RCL_OPT_PREFIX . '_licenseActivated';
        $value = '1';
        
        if ($set !== null) {
            if ($set) {
                set_site_transient($transient, $value, 365 * DAY_IN_SECONDS);
            }else{
                delete_site_transient($transient);
            }
        }
        
        return get_site_transient($transient) === $value;
    }
    
    /**
     * Show a notice in the plugins list that the plugin is not activated, yet.
     */
    public function after_plugin_row($file, $plugin) {
        $wp_list_table = _get_list_table('WP_Plugins_List_Table');
		printf(
			'<tr class="rcl-update-notice active">
	<th colspan="%d" class="check-column">
    	<div class="plugin-update update-message notice inline notice-warning notice-alt">
        	<div class="update-message">%s</div>
    	</div>
    </th>
</tr>',
			$wp_list_table->get_column_count(),
			wpautop(__('<strong>You have not yet entered the license key</strong>. To receive automatic updates, please enter the key in "Enter license".', RCL_TD))
		);
    }
    
    /**
     * Get singleton core class.
     * 
     * @returns Core
     */
    public static function getInstance() {
        return !isset(self::$me) ? self::$me = new Core() : self::$me;
    }
}