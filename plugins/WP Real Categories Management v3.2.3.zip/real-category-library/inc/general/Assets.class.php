<?php
namespace MatthiasWeb\RealCategoryLibrary\general;
use MatthiasWeb\RealCategoryLibrary\base;
use MatthiasWeb\RealCategoryLibrary\rest;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

/**
 * Asset management for frontend scripts and styles.
 */
class Assets extends base\Assets {
    
    /**
     * Enqueue scripts and styles depending on the type. This function is called
     * from both admin_enqueue_scripts and wp_enqueue_scripts. You can check the
     * type through the $type parameter. In this function you can include your
     * external libraries from public/lib, too.
     * 
     * @param string $type The type (see base\Assets constants)
     */
    public function enqueue_scripts_and_styles($type) {
        if (!wp_rcl_active()) {
            return;
        }
        
        $publicFolder = $this->getPublicFolder();
        $isDebug = $this->isScriptDebug();
        $dpSuffix = $isDebug ? 'development' : 'production.min';
        $minSuffix = $isDebug ? '' : '.min';
        
        // Your assets implementation here... See base\Assets for enqueue* methods.
        if ($type === base\Assets::TYPE_ADMIN) {
            // jQuery scripts (Helper) core.js, widget.js, mouse.js, draggable.js, droppable.js, sortable.js
        	$requires = array("jquery", "jquery-ui-core", "jquery-ui-widget", "jquery-ui-mouse", "jquery-ui-draggable", "jquery-ui-droppable", "jquery-ui-sortable", "jquery-touch-punch");
            array_walk($requires, 'wp_enqueue_script');
            
            // ES6/ES7 polyfill
            $this->enqueueLibraryScript('es6-shim', 'es6-shim/es6-shim.min.js');
            $this->enqueueLibraryScript('es7-shim', 'es7-shim/dist/es7-shim.min.js', array('es6-shim'));
            
            // React / ReactDOM
            $this->enqueueLibraryScript('react', 'react/umd/react.' . $dpSuffix . '.js', array('es7-shim'));
            $this->enqueueLibraryScript('react-dom', 'react-dom/umd/react-dom.' . $dpSuffix . '.js', array('react', 'es7-shim'));
            
            // SortableJs
            $this->enqueueLibraryScript('sortablejs', 'sortablejs/Sortable' . $minSuffix . '.js', $requires);
            
            // i18n-react
            $this->enqueueLibraryScript('i18n-react', 'i18n-react/dist/i18n-react.umd' . $minSuffix . '.js', array('react-dom'));
            
            // mobx
            $this->enqueueLibraryScript('mobx', 'mobx/lib/mobx.umd' . $minSuffix . '.js');
            
            // mobx-state-tree
            $this->enqueueLibraryScript('mobx-state-tree', 'mobx-state-tree/dist/mobx-state-tree.umd.js', array('mobx'));
            
            // immer
            $this->enqueueLibraryScript('immer', 'immer/dist/immer.umd.js');
            
            // React AIOT
            $this->enqueueLibraryScript('react-aiot.vendor', 'react-aiot/umd/react-aiot.vendor.umd.js', array('react-dom'));
            $this->enqueueLibraryStyle('react-aiot.vendor', 'react-aiot/umd/react-aiot.vendor.umd.css');
            $this->enqueueLibraryScript('react-aiot', 'react-aiot/umd/react-aiot.umd.js', array('react-aiot.vendor'));
            $this->enqueueLibraryStyle('react-aiot', 'react-aiot/umd/react-aiot.umd.css');
            
            // React AIOT watch mode in local development environment
            //wp_enqueue_script('react-aiot.vendor', '/repos/react-aiot/umd/react-aiot.vendor.umd.js', array('react-dom'), rand(), true);
            //wp_enqueue_style('react-aiot.vendor', '/repos/react-aiot/umd/react-aiot.vendor.umd.css', array(), rand());
            //wp_enqueue_script('react-aiot', '/repos/react-aiot/umd/react-aiot.umd.js', array('react-aiot.vendor'), rand(), true);
            //wp_enqueue_style('react-aiot', '/repos/react-aiot/umd/react-aiot.umd.css', array(), rand());
            
            // Plugin scripts
            wp_enqueue_script('wp-api');
            $this->enqueueScript('real-category-library', 'admin.js', array('react-dom', 'sortablejs', 'i18n-react', 'immer', 'wp-api'));
		    $this->enqueueStyle('real-category-library', 'admin.css');
		    wp_localize_script('real-category-library', 'rclOpts', $this->adminLocalizeScript());
        }
    }
    
    /**
     * Localize the WordPress admin backend.
     * 
     * @returns array
     */
    public function adminLocalizeScript() {
        $core = $this->getCore();
        $defaultTaxTree = $core->getDefaultTaxTree();
        $screenSettings = $core->getScreenSettings();
        $isLicenseActivated = $core->getUpdater()->isActivated();
        $isLicenseNoticeDismissed = $core->isLicenseNoticeDismissed();
        
        $lang = new Lang();
        return apply_filters('RCL/Localize', array(
            'isAvailable' => $defaultTaxTree->isAvailable(),
            'screenSettings' => array(
                'isActive' => $screenSettings->isActive($defaultTaxTree),
                'isFastMode' => $screenSettings->isFastMode($defaultTaxTree)
            ),
            'textDomain' => RCL_TD,
            'restUrl' => rest\Service::getUrl(rest\Service::SERVICE_NAMESPACE),
            'restRoot' => get_rest_url(),
            'restNonce' => ( wp_installing() && ! is_multisite() ) ? '' : wp_create_nonce( 'wp_rest' ),
            'restQuery' => array('_v' => RCL_VERSION),
            'blogId' => get_current_blog_id(),
            'simplePageOrdering' => is_plugin_active("simple-page-ordering/simple-page-ordering.php"),
            'simplePageOrderingLink' => admin_url('plugin-install.php?tab=search&s=simple+page+ordering'),
            'editOrderBy' => isset($_GET['orderby']) ? $_GET['orderby'] : '',
            'editOrder' => isset($_GET['order']) ? $_GET['order'] : '',
            'typenow' => $defaultTaxTree->getTypeNow(),
            'taxnow' => $defaultTaxTree->getTaxNow() !== null ? $defaultTaxTree->getTaxNow()->objkey : '',
            'allPostCnt' => $defaultTaxTree->getPostCnt(),
            'taxos' => $defaultTaxTree->getTaxos(true),
            'lang' => $lang->getItems(),
            'showLicenseNotice' => !$isLicenseActivated && !$isLicenseNoticeDismissed && current_user_can('install_plugins'),
            'pluginsUrl' => admin_url('plugins.php')
        ));
    }
    
    /**
     * Enqueue scripts and styles for admin pages.
     */
    public function admin_enqueue_scripts() {
        $this->enqueue_scripts_and_styles(base\Assets::TYPE_ADMIN);
    }
    
    /**
     * Enqueue scripts and styles for frontend pages.
     */
    public function wp_enqueue_scripts() {
        $this->enqueue_scripts_and_styles(base\Assets::TYPE_FRONTEND);
    }
    
    /**
     * Checks if the current screen has a given base.
     * 
     * @param string $base The base name
     * @param boolean $log Log the current screen base to error log
     * @returns boolean
     */
    public function isScreenBase($base, $log = false) {
        if (function_exists("get_current_screen")) {
            $screen = get_current_screen();
        }else{
            return false;
        }
        
        if ($log) {
            error_log($screen->base);
        }
        
        if (isset($screen->base)) {
            return $screen->base == $base;
        }else{
            return false;
        }
    }
}