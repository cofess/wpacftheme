<?php
namespace MatthiasWeb\RealCategoryLibrary\general;
use MatthiasWeb\RealCategoryLibrary\base;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

/**
 * Language texts.
 */
class Lang extends base\Base {
    /**
     * Get an array of language keys and translations.
     * 
     * @returns array
     */
    public function getItems() {
        return array(
            'new'                   => __('New', RCL_TD),
            'categories'            => __('Categories', RCL_TD),
            'allPosts'              => __('All posts', RCL_TD),
            'noEntries'             => __('No posts found.'),
            'cancel'                => __('Cancel', RCL_TD),
            'back'                  => __('Back', RCL_TD),
            'ok'                    => __('OK', RCL_TD),
            'save'                  => __('Save', RCL_TD),
            'noFoldersTitle'        => __('No category found', RCL_TD),
            'noFoldersDescription'  => __('Click the above button to create a new category.', RCL_TD),
            'noSearchResult'        => __('No search results found', RCL_TD),
            'addLoadingText'        => __('Creating *{name}*...', RCL_TD),
            'addSuccess'            => __('*{name}* successfully created.', RCL_TD),
            
            'renameLoadingText'     => __('Renaming *{name}*...', RCL_TD),
            'renameSuccess'         => __('*{name}* successfully renamed.', RCL_TD),
            
            'deleteConfirm'         => __('Are you sure to delete *{name}*? Note: The posts in this category *are NOT deleted* automatically', RCL_TD),
            'deleteFailedSub'       => __('You can not delete *{name}* because it contains subcategories.', RCL_TD),
            'deleteSuccess'         => __('*{name}* successfully deleted.', RCL_TD),
            
            'sortLoadingText'       => __('The category tree will be reordered soon...', RCL_TD),
            'sortedSuccess'         => __('The category tree is successfully reordered.', RCL_TD),
            
            'creatableToolTipTitle' => __('Click this to create a new category', RCL_TD),
            'creatableToolTipText'  => __('If you want to create a sub-category simply select a category from the list and click this button.', RCL_TD),
            'refreshToolTipTitle'   => __('Refresh', RCL_TD),
            'refreshToolTipText'    => __('Refreshes the current category view.', RCL_TD),
            'renameToolTipTitle'    => __('Rename', RCL_TD),
            'renameToolTipText'     => __('Rename the current selected category.', RCL_TD),
            'trashToolTipTitle'     => __('Delete', RCL_TD),
            'trashToolTipText'      => __('Delete the current selected category.', RCL_TD),
            'orderToolTipTitle'     => __('Reorder entries', RCL_TD),
            'orderToolTipText'      => __('Start to reorder the entries with the help of *Simple Page Ordering*.', RCL_TD),
            'sortToolTipTitle'      => __('Rearrange', RCL_TD),
            'sortToolTipText'       => __('Change the hierarchical order of the categories.', RCL_TD),
            'noSimplePageOrdering'  => __('*Simple Page Ordering* is not available here. You can only reorder post types with hierarchical structure and an *Order* attribute.', RCL_TD),
            'installSimplePageOrdering' => __('If you want to use custom order functionality for this post type you must install and activate the plugin *Simple Page Ordering*.', RCL_TD),
            'installPlugin'         => __('Install plugin', RCL_TD),
            'learnMore'             => __('Learn more', RCL_TD),
            
            'moveOne'               => __('Move post', RCL_TD),
            'move'                  => __('Move {count} posts', RCL_TD),
            'moveTip'               => __('Hold any key to copy to category', RCL_TD),
            'appendOne'             => __('Copy post', RCL_TD),
            'append'                => __('Copy {count} posts', RCL_TD),
            'appendTip'             => __('Release key to move', RCL_TD),
            
            'moveLoadingTextOne'    => __('Moving post to *{category}*...', RCL_TD),
            'moveLoadingText'       => __('Moving {count} posts to *{category}*...', RCL_TD),
            'moveSuccessOne'        => __('Post successfully moved.', RCL_TD),
            'moveSuccess'           => __('{count} posts successfully moved.', RCL_TD),
            'appendLoadingTextOne'  => __('Copy post to *{category}*...', RCL_TD),
            'appendLoadingText'     => __('Copy {count} posts to *{category}*...', RCL_TD),
            'appendSuccessOne'      => __('Post successfully copied.', RCL_TD),
            'appendSuccess'         => __('{count} posts successfully copied.', RCL_TD),
            'methodNotAllowed405'   => __('An error occured during requesting the Real Category Management REST endpoint *{endpoint}* from the server (_405 Method not allowed_). One reason can be that your server configuration is missing something.', RCL_TD),
            'methodNotAllowed405LinkText' => __('Click here to learn how to resolve this (external link)', RCL_TD),
            'methodMoved301'        => __('It seems the tree could not be fetched because the WP REST API endpoint *tree* is not reachable. Do you use a plugin which disables the WP REST API like *Clearfy*?', RCL_TD)
        );
    }
}