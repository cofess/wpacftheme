<?php
namespace MatthiasWeb\RealCategoryLibrary\options;
use MatthiasWeb\RealCategoryLibrary\base;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

/**
 * Screen settings for every post type / taxonomy.
 */
class ScreenSettings extends base\Base {
    
    /**
     * Returns if the tree is active for the given taxonomy tree.
     * 
     * @param general\TaxTree $taxTree The taxonomy tree
     * @returns boolean
     */
    public function isActive($taxTree) {
        return (boolean) get_option('rcl-active-' .  $taxTree->getTypeNow(), 1);
    }
    
    /**
     * Returns if the tree is fast mode for the given taxonomy tree.
     * 
     * @param general\TaxTree $taxTree The taxonomy tree
     * @returns boolean
     */
    public function isFastMode($taxTree) {
        return (boolean) get_option('rcl-fast-mode-' .  $taxTree->getTypeNow(), 1);
    }
    
    /**
     * Save the screen options over the nonce checker.
     * The nonce name is "screen-options-nonce".
     */
    public function check_admin_referer($action, $result) {
        if ($action === 'screen-options-nonce' && $result) {
            $typenow = isset($_GET['post_type']) ? $_GET['post_type'] : 'post';
            $checkbox = array('rcl-active', 'rcl-fast-mode');
            require_once(ABSPATH . WPINC . DIRECTORY_SEPARATOR . 'option.php');
            foreach ($checkbox as $name) {
                update_option($name . '-' . $typenow, isset($_POST[$name]) && $_POST[$name] == '1' ? '1' : '0');
            }
        }
    }
    
    /**
     * Show the screen settings for available post types.
     */
    public function screen_settings($settings) {
        $taxTree = $this->getCore()->getDefaultTaxTree();
        if (!$taxTree->isAvailable()) {
            return $settings;
        }
        
        $settings .= '<fieldset class="metabox-prefs">
    		<legend>' . __('Advanced Settings for this post type', RCL_TD) . '</legend>
    		<label><input class="hide-column-tog" name="rcl-active" type="checkbox" id="rcl-active" value="1" ' . checked($this->isActive($taxTree), 1, false) . '>' . __('Tree view', RCL_TD) . '</label>
            <label><input class="hide-column-tog" name="rcl-fast-mode" type="checkbox" id="rcl-fast-categories-off" value="1" ' . checked($this->isFastMode($taxTree), 1, false) . '>' . __('Avoid page reload (tree view must be active)', RCL_TD) . '</label>
		</fieldset>';
		
		return $settings;
    }
}