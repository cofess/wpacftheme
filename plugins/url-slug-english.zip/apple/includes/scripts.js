jQuery(document).ready(function($) {

    /* 初始化时显示的翻译源 */
    var val = $('[name*=translation_from]').val();
    switch ( parseInt( val ) ) {
        case 0:
            // 谷歌
            $('#baidu-translate').hide()
            $('#youdao-translate').hide();
            break;
        case 1:
            // 百度
            $('#youdao-translate').hide();

            $('#baidu-translate').show();
            break;
        case 2:
            // 有道
            $('#baidu-translate').hide()

            $('#youdao-translate').show();
            break;
        default:

            break;
    }

    /* 翻译源变化时显示相应的api配置框 */
    $('body').on('change', '[name*=translation_from]', function(event) {
        var val =  $(this).val()
        switch ( parseInt( val ) ) {
            case 0:
                // 谷歌
                $('#baidu-translate').hide()
                $('#youdao-translate').hide();
                break;
            case 1:
                // 百度
                $('#youdao-translate').hide();

                $('#baidu-translate').show();
                break;
            case 2:
                // 有道
                $('#baidu-translate').hide()

                $('#youdao-translate').show();
                break;
            default:

                break;
        }
    });


});

