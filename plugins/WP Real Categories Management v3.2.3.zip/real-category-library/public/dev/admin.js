/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./public/src/admin.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime-module.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime-module.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
// This method of obtaining a reference to the global object needs to be
// kept identical to the way it is obtained in runtime.js
var g = function () {
  return this || typeof self === "object" && self;
}() || Function("return this")(); // Use `getOwnPropertyNames` because not all browsers support calling
// `hasOwnProperty` on the global `self` object in a worker. See #183.


var hadRuntime = g.regeneratorRuntime && Object.getOwnPropertyNames(g).indexOf("regeneratorRuntime") >= 0; // Save the old regeneratorRuntime in case it needs to be restored later.

var oldRuntime = hadRuntime && g.regeneratorRuntime; // Force reevalutation of runtime.js.

g.regeneratorRuntime = undefined;
module.exports = __webpack_require__(/*! ./runtime */ "./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime.js");

if (hadRuntime) {
  // Restore the original runtime.
  g.regeneratorRuntime = oldRuntime;
} else {
  // Remove the global property added by runtime.js.
  try {
    delete g.regeneratorRuntime;
  } catch (e) {
    g.regeneratorRuntime = undefined;
  }
}

/***/ }),

/***/ "./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
!function (global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.

  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;

  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    } // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.


    return;
  } // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.


  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []); // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.

    generator._invoke = makeInvokeMethod(innerFn, self, context);
    return generator;
  }

  runtime.wrap = wrap; // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.

  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed"; // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.

  var ContinueSentinel = {}; // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.

  function Generator() {}

  function GeneratorFunction() {}

  function GeneratorFunctionPrototype() {} // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.


  var IteratorPrototype = {};

  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));

  if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] = GeneratorFunction.displayName = "GeneratorFunction"; // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.

  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      prototype[method] = function (arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function (genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
    // do is to check its .name property.
    (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
  };

  runtime.mark = function (genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;

      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }

    genFun.prototype = Object.create(Gp);
    return genFun;
  }; // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.


  runtime.awrap = function (arg) {
    return {
      __await: arg
    };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);

      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;

        if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function (value) {
            invoke("next", value, resolve, reject);
          }, function (err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function (unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function (error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function (resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise = // If enqueue has been called before, then we want to wait until
      // all previous Promises have been resolved before calling invoke,
      // so that results are always delivered in the correct order. If
      // enqueue has not been called before, then it is important to
      // call invoke immediately, without waiting on a callback to fire,
      // so that the async generator function has the opportunity to do
      // any necessary setup in a predictable way. This predictability
      // is why the Promise constructor synchronously invokes its
      // executor callback, and why async functions synchronously
      // execute code before the first await. Since we implement simple
      // async functions in terms of async generators, it is especially
      // important to get this right, even though it requires care.
      previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, // Avoid propagating failures to Promises returned by later
      // invocations of the iterator.
      callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    } // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).


    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);

  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };

  runtime.AsyncIterator = AsyncIterator; // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.

  runtime.async = function (innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList));
    return runtime.isGeneratorFunction(outerFn) ? iter // If outerFn is a generator, return the full iterator.
    : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;
    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        } // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume


        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;

        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);

          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;
        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);
        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;
        var record = tryCatch(innerFn, self, context);

        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done ? GenStateCompleted : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };
        } else if (record.type === "throw") {
          state = GenStateCompleted; // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.

          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  } // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.


  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];

    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (!info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value; // Resume execution at the desired location (see delegateYield).

      context.next = delegate.nextLoc; // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.

      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }
    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    } // The delegate iterator is finished, so forget it and continue with
    // the outer generator.


    context.delegate = null;
    return ContinueSentinel;
  } // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.


  defineIteratorMethods(Gp);
  Gp[toStringTagSymbol] = "Generator"; // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.

  Gp[iteratorSymbol] = function () {
    return this;
  };

  Gp.toString = function () {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{
      tryLoc: "root"
    }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function (object) {
    var keys = [];

    for (var key in object) {
      keys.push(key);
    }

    keys.reverse(); // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.

    return function next() {
      while (keys.length) {
        var key = keys.pop();

        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      } // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.


      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];

      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1,
            next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;
          return next;
        };

        return next.next = next;
      }
    } // Return an iterator with no values.


    return {
      next: doneResult
    };
  }

  runtime.values = values;

  function doneResult() {
    return {
      value: undefined,
      done: true
    };
  }

  Context.prototype = {
    constructor: Context,
    reset: function (skipTempReset) {
      this.prev = 0;
      this.next = 0; // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.

      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;
      this.method = "next";
      this.arg = undefined;
      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },
    stop: function () {
      this.done = true;
      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;

      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },
    dispatchException: function (exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;

      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !!caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }
          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },
    abrupt: function (type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];

        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },
    complete: function (record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" || record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },
    finish: function (finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];

        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },
    "catch": function (tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];

        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;

          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }

          return thrown;
        }
      } // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.


      throw new Error("illegal catch attempt");
    },
    delegateYield: function (iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
}( // In sloppy mode, unbound `this` refers to the global object, fallback to
// Function constructor if we're in global strict mode. That is sadly a form
// of indirect eval which violates Content Security Policy.
function () {
  return this || typeof self === "object" && self;
}() || Function("return this")());

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "./node_modules/@babel/runtime/node_modules/regenerator-runtime/runtime-module.js");

/***/ }),

/***/ "./node_modules/lil-uri/uri.js":
/*!*************************************!*\
  !*** ./node_modules/lil-uri/uri.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*! lil-uri - v0.2.0 - MIT License - https://github.com/lil-js/uri */
;

(function (root, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [exports], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else {}
})(this, function (exports) {
  'use strict';

  var VERSION = '0.2.2';
  var REGEX = /^(?:([^:\/?#]+):\/\/)?((?:([^\/?#@]*)@)?([^\/?#:]*)(?:\:(\d*))?)?([^?#]*)(?:\?([^#]*))?(?:#((?:.|\n)*))?/i;

  function isStr(o) {
    return typeof o === 'string';
  }

  function decode(uri) {
    return decodeURIComponent(escape(uri));
  }

  function mapSearchParams(search) {
    var map = {};

    if (typeof search === 'string') {
      search.split('&').forEach(function (values) {
        values = values.split('=');

        if (map.hasOwnProperty(values[0])) {
          map[values[0]] = Array.isArray(map[values[0]]) ? map[values[0]] : [map[values[0]]];
          map[values[0]].push(values[1]);
        } else {
          map[values[0]] = values[1];
        }
      });
      return map;
    }
  }

  function accessor(type) {
    return function (value) {
      if (value) {
        this.parts[type] = isStr(value) ? decode(value) : value;
        return this;
      }

      this.parts = this.parse(this.build());
      return this.parts[type];
    };
  }

  function URI(uri) {
    this.uri = uri || null;

    if (isStr(uri) && uri.length) {
      this.parts = this.parse(uri);
    } else {
      this.parts = {};
    }
  }

  URI.prototype.parse = function (uri) {
    var parts = decode(uri || '').match(REGEX);
    var auth = (parts[3] || '').split(':');
    var host = auth.length ? (parts[2] || '').replace(/(.*\@)/, '') : parts[2];
    return {
      uri: parts[0],
      protocol: parts[1],
      host: host,
      hostname: parts[4],
      port: parts[5],
      auth: parts[3],
      user: auth[0],
      password: auth[1],
      path: parts[6],
      search: parts[7],
      query: mapSearchParams(parts[7]),
      hash: parts[8]
    };
  };

  URI.prototype.protocol = function (host) {
    return accessor('protocol').call(this, host);
  };

  URI.prototype.host = function (host) {
    return accessor('host').call(this, host);
  };

  URI.prototype.hostname = function (hostname) {
    return accessor('hostname').call(this, hostname);
  };

  URI.prototype.port = function (port) {
    return accessor('port').call(this, port);
  };

  URI.prototype.auth = function (auth) {
    return accessor('host').call(this, auth);
  };

  URI.prototype.user = function (user) {
    return accessor('user').call(this, user);
  };

  URI.prototype.password = function (password) {
    return accessor('password').call(this, password);
  };

  URI.prototype.path = function (path) {
    return accessor('path').call(this, path);
  };

  URI.prototype.search = function (search) {
    return accessor('search').call(this, search);
  };

  URI.prototype.query = function (query) {
    return query && typeof query === 'object' ? accessor('query').call(this, query) : this.parts.query;
  };

  URI.prototype.hash = function (hash) {
    return accessor('hash').call(this, hash);
  };

  URI.prototype.get = function (value) {
    return this.parts[value] || '';
  };

  URI.prototype.build = URI.prototype.toString = URI.prototype.valueOf = function () {
    var p = this.parts,
        buf = [];
    if (p.protocol) buf.push(p.protocol + '://');
    if (p.auth) buf.push(p.auth + '@');else if (p.user) buf.push(p.user + (p.password ? ':' + p.password : '') + '@');

    if (p.host) {
      buf.push(p.host);
    } else {
      if (p.hostname) buf.push(p.hostname);
      if (p.port) buf.push(':' + p.port);
    }

    if (p.path) buf.push(p.path);

    if (p.query && typeof p.query === 'object') {
      if (!p.path) buf.push('/');
      buf.push('?' + Object.keys(p.query).map(function (name) {
        if (Array.isArray(p.query[name])) {
          return p.query[name].map(function (value) {
            return name + (value ? '=' + value : '');
          }).join('&');
        } else {
          return name + (p.query[name] ? '=' + p.query[name] : '');
        }
      }).join('&'));
    } else if (p.search) {
      buf.push('?' + p.search);
    }

    if (p.hash) {
      if (!p.path) buf.push('/');
      buf.push('#' + p.hash);
    }

    return this.url = buf.filter(function (part) {
      return isStr(part);
    }).join('');
  };

  function uri(uri) {
    return new URI(uri);
  }

  function isURL(uri) {
    return typeof uri === 'string' && REGEX.test(uri);
  }

  uri.VERSION = VERSION;
  uri.is = uri.isURL = isURL;
  uri.URI = URI;
  return exports.uri = uri;
});

/***/ }),

/***/ "./node_modules/mobx-react/index.module.js":
/*!*************************************************!*\
  !*** ./node_modules/mobx-react/index.module.js ***!
  \*************************************************/
/*! exports provided: propTypes, PropTypes, onError, observer, Observer, renderReporter, componentByNodeRegistery, componentByNodeRegistry, trackComponents, useStaticRendering, Provider, inject */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "propTypes", function() { return propTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropTypes", function() { return propTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onError", function() { return onError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "observer", function() { return observer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Observer", function() { return Observer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renderReporter", function() { return renderReporter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "componentByNodeRegistery", function() { return componentByNodeRegistry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "componentByNodeRegistry", function() { return componentByNodeRegistry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trackComponents", function() { return trackComponents; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useStaticRendering", function() { return useStaticRendering; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Provider", function() { return Provider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inject", function() { return inject; });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mobx */ "mobx");
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);


 // These functions can be stubbed out in specific environments

var unstable_batchedUpdates$1 = undefined;
'use strict';
/**
 * Copyright 2015, Yahoo! Inc.
 * Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
 */


var REACT_STATICS = {
  childContextTypes: true,
  contextTypes: true,
  defaultProps: true,
  displayName: true,
  getDefaultProps: true,
  getDerivedStateFromProps: true,
  mixins: true,
  propTypes: true,
  type: true
};
var KNOWN_STATICS = {
  name: true,
  length: true,
  prototype: true,
  caller: true,
  callee: true,
  arguments: true,
  arity: true
};
var defineProperty = Object.defineProperty;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = getPrototypeOf && getPrototypeOf(Object);

function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
  if (typeof sourceComponent !== 'string') {
    // don't hoist over string (html) components
    if (objectPrototype) {
      var inheritedComponent = getPrototypeOf(sourceComponent);

      if (inheritedComponent && inheritedComponent !== objectPrototype) {
        hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
      }
    }

    var keys = getOwnPropertyNames(sourceComponent);

    if (getOwnPropertySymbols) {
      keys = keys.concat(getOwnPropertySymbols(sourceComponent));
    }

    for (var i = 0; i < keys.length; ++i) {
      var key = keys[i];

      if (!REACT_STATICS[key] && !KNOWN_STATICS[key] && (!blacklist || !blacklist[key])) {
        var descriptor = getOwnPropertyDescriptor(sourceComponent, key);

        try {
          // Avoid failures from read-only properties
          defineProperty(targetComponent, key, descriptor);
        } catch (e) {}
      }
    }

    return targetComponent;
  }

  return targetComponent;
}

var hoistNonReactStatics_cjs = hoistNonReactStatics;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();

var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var inherits = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
};

var possibleConstructorReturn = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && (typeof call === "object" || typeof call === "function") ? call : self;
};

var EventEmitter = function () {
  function EventEmitter() {
    classCallCheck(this, EventEmitter);
    this.listeners = [];
  }

  createClass(EventEmitter, [{
    key: "on",
    value: function on(cb) {
      var _this = this;

      this.listeners.push(cb);
      return function () {
        var index = _this.listeners.indexOf(cb);

        if (index !== -1) _this.listeners.splice(index, 1);
      };
    }
  }, {
    key: "emit",
    value: function emit(data) {
      this.listeners.forEach(function (fn) {
        return fn(data);
      });
    }
  }]);
  return EventEmitter;
}(); // Copied from React.PropTypes


function createChainableTypeChecker(validate) {
  function checkType(isRequired, props, propName, componentName, location, propFullName) {
    for (var _len = arguments.length, rest = Array(_len > 6 ? _len - 6 : 0), _key = 6; _key < _len; _key++) {
      rest[_key - 6] = arguments[_key];
    }

    return Object(mobx__WEBPACK_IMPORTED_MODULE_0__["untracked"])(function () {
      componentName = componentName || "<<anonymous>>";
      propFullName = propFullName || propName;

      if (props[propName] == null) {
        if (isRequired) {
          var actual = props[propName] === null ? "null" : "undefined";
          return new Error("The " + location + " `" + propFullName + "` is marked as required " + "in `" + componentName + "`, but its value is `" + actual + "`.");
        }

        return null;
      } else {
        return validate.apply(undefined, [props, propName, componentName, location, propFullName].concat(rest));
      }
    });
  }

  var chainedCheckType = checkType.bind(null, false);
  chainedCheckType.isRequired = checkType.bind(null, true);
  return chainedCheckType;
} // Copied from React.PropTypes


function isSymbol(propType, propValue) {
  // Native Symbol.
  if (propType === "symbol") {
    return true;
  } // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'


  if (propValue["@@toStringTag"] === "Symbol") {
    return true;
  } // Fallback for non-spec compliant Symbols which are polyfilled.


  if (typeof Symbol === "function" && propValue instanceof Symbol) {
    return true;
  }

  return false;
} // Copied from React.PropTypes


function getPropType(propValue) {
  var propType = typeof propValue === "undefined" ? "undefined" : _typeof(propValue);

  if (Array.isArray(propValue)) {
    return "array";
  }

  if (propValue instanceof RegExp) {
    // Old webkits (at least until Android 4.0) return 'function' rather than
    // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
    // passes PropTypes.object.
    return "object";
  }

  if (isSymbol(propType, propValue)) {
    return "symbol";
  }

  return propType;
} // This handles more types than `getPropType`. Only used for error messages.
// Copied from React.PropTypes


function getPreciseType(propValue) {
  var propType = getPropType(propValue);

  if (propType === "object") {
    if (propValue instanceof Date) {
      return "date";
    } else if (propValue instanceof RegExp) {
      return "regexp";
    }
  }

  return propType;
}

function createObservableTypeCheckerCreator(allowNativeType, mobxType) {
  return createChainableTypeChecker(function (props, propName, componentName, location, propFullName) {
    return Object(mobx__WEBPACK_IMPORTED_MODULE_0__["untracked"])(function () {
      if (allowNativeType) {
        if (getPropType(props[propName]) === mobxType.toLowerCase()) return null;
      }

      var mobxChecker = void 0;

      switch (mobxType) {
        case "Array":
          mobxChecker = mobx__WEBPACK_IMPORTED_MODULE_0__["isObservableArray"];
          break;

        case "Object":
          mobxChecker = mobx__WEBPACK_IMPORTED_MODULE_0__["isObservableObject"];
          break;

        case "Map":
          mobxChecker = mobx__WEBPACK_IMPORTED_MODULE_0__["isObservableMap"];
          break;

        default:
          throw new Error("Unexpected mobxType: " + mobxType);
      }

      var propValue = props[propName];

      if (!mobxChecker(propValue)) {
        var preciseType = getPreciseType(propValue);
        var nativeTypeExpectationMessage = allowNativeType ? " or javascript `" + mobxType.toLowerCase() + "`" : "";
        return new Error("Invalid prop `" + propFullName + "` of type `" + preciseType + "` supplied to" + " `" + componentName + "`, expected `mobx.Observable" + mobxType + "`" + nativeTypeExpectationMessage + ".");
      }

      return null;
    });
  });
}

function createObservableArrayOfTypeChecker(allowNativeType, typeChecker) {
  return createChainableTypeChecker(function (props, propName, componentName, location, propFullName) {
    for (var _len2 = arguments.length, rest = Array(_len2 > 5 ? _len2 - 5 : 0), _key2 = 5; _key2 < _len2; _key2++) {
      rest[_key2 - 5] = arguments[_key2];
    }

    return Object(mobx__WEBPACK_IMPORTED_MODULE_0__["untracked"])(function () {
      if (typeof typeChecker !== "function") {
        return new Error("Property `" + propFullName + "` of component `" + componentName + "` has " + "invalid PropType notation.");
      }

      var error = createObservableTypeCheckerCreator(allowNativeType, "Array")(props, propName, componentName);
      if (error instanceof Error) return error;
      var propValue = props[propName];

      for (var i = 0; i < propValue.length; i++) {
        error = typeChecker.apply(undefined, [propValue, i, componentName, location, propFullName + "[" + i + "]"].concat(rest));
        if (error instanceof Error) return error;
      }

      return null;
    });
  });
}

var observableArray = createObservableTypeCheckerCreator(false, "Array");
var observableArrayOf = createObservableArrayOfTypeChecker.bind(null, false);
var observableMap = createObservableTypeCheckerCreator(false, "Map");
var observableObject = createObservableTypeCheckerCreator(false, "Object");
var arrayOrObservableArray = createObservableTypeCheckerCreator(true, "Array");
var arrayOrObservableArrayOf = createObservableArrayOfTypeChecker.bind(null, true);
var objectOrObservableObject = createObservableTypeCheckerCreator(true, "Object");
var propTypes = Object.freeze({
  observableArray: observableArray,
  observableArrayOf: observableArrayOf,
  observableMap: observableMap,
  observableObject: observableObject,
  arrayOrObservableArray: arrayOrObservableArray,
  arrayOrObservableArrayOf: arrayOrObservableArrayOf,
  objectOrObservableObject: objectOrObservableObject
});

function isStateless(component) {
  // `function() {}` has prototype, but `() => {}` doesn't
  // `() => {}` via Babel has prototype too.
  return !(component.prototype && component.prototype.render);
}

var injectorContextTypes = {
  mobxStores: objectOrObservableObject
};
Object.seal(injectorContextTypes);
var proxiedInjectorProps = {
  contextTypes: {
    get: function get$$1() {
      return injectorContextTypes;
    },
    set: function set$$1(_) {
      console.warn("Mobx Injector: you are trying to attach `contextTypes` on an component decorated with `inject` (or `observer`) HOC. Please specify the contextTypes on the wrapped component instead. It is accessible through the `wrappedComponent`");
    },
    configurable: true,
    enumerable: false
  },
  isMobxInjector: {
    value: true,
    writable: true,
    configurable: true,
    enumerable: true
    /**
     * Store Injection
     */

  }
};

function createStoreInjector(grabStoresFn, component, injectNames) {
  var _class, _temp2;

  var displayName = "inject-" + (component.displayName || component.name || component.constructor && component.constructor.name || "Unknown");
  if (injectNames) displayName += "-with-" + injectNames;
  var Injector = (_temp2 = _class = function (_Component) {
    inherits(Injector, _Component);

    function Injector() {
      var _ref;

      var _temp, _this, _ret;

      classCallCheck(this, Injector);

      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return _ret = (_temp = (_this = possibleConstructorReturn(this, (_ref = Injector.__proto__ || Object.getPrototypeOf(Injector)).call.apply(_ref, [this].concat(args))), _this), _this.storeRef = function (instance) {
        _this.wrappedInstance = instance;
      }, _temp), possibleConstructorReturn(_this, _ret);
    }

    createClass(Injector, [{
      key: "render",
      value: function render() {
        // Optimization: it might be more efficient to apply the mapper function *outside* the render method
        // (if the mapper is a function), that could avoid expensive(?) re-rendering of the injector component
        // See this test: 'using a custom injector is not too reactive' in inject.js
        var newProps = {};

        for (var key in this.props) {
          if (this.props.hasOwnProperty(key)) {
            newProps[key] = this.props[key];
          }
        }

        var additionalProps = grabStoresFn(this.context.mobxStores || {}, newProps, this.context) || {};

        for (var _key2 in additionalProps) {
          newProps[_key2] = additionalProps[_key2];
        }

        if (!isStateless(component)) {
          newProps.ref = this.storeRef;
        }

        return Object(react__WEBPACK_IMPORTED_MODULE_1__["createElement"])(component, newProps);
      }
    }]);
    return Injector;
  }(react__WEBPACK_IMPORTED_MODULE_1__["Component"]), _class.displayName = displayName, _temp2); // Static fields from component should be visible on the generated Injector

  hoistNonReactStatics_cjs(Injector, component);
  Injector.wrappedComponent = component;
  Object.defineProperties(Injector, proxiedInjectorProps);
  return Injector;
}

function grabStoresByName(storeNames) {
  return function (baseStores, nextProps) {
    storeNames.forEach(function (storeName) {
      if (storeName in nextProps // prefer props over stores
      ) return;
      if (!(storeName in baseStores)) throw new Error("MobX injector: Store '" + storeName + "' is not available! Make sure it is provided by some Provider");
      nextProps[storeName] = baseStores[storeName];
    });
    return nextProps;
  };
}
/**
 * higher order component that injects stores to a child.
 * takes either a varargs list of strings, which are stores read from the context,
 * or a function that manually maps the available stores from the context to props:
 * storesToProps(mobxStores, props, context) => newProps
 */


function inject()
/* fn(stores, nextProps) or ...storeNames */
{
  var grabStoresFn = void 0;

  if (typeof arguments[0] === "function") {
    grabStoresFn = arguments[0];
    return function (componentClass) {
      var injected = createStoreInjector(grabStoresFn, componentClass);
      injected.isMobxInjector = false; // supress warning
      // mark the Injector as observer, to make it react to expressions in `grabStoresFn`,
      // see #111

      injected = observer(injected);
      injected.isMobxInjector = true; // restore warning

      return injected;
    };
  } else {
    var storeNames = [];

    for (var i = 0; i < arguments.length; i++) {
      storeNames[i] = arguments[i];
    }

    grabStoresFn = grabStoresByName(storeNames);
    return function (componentClass) {
      return createStoreInjector(grabStoresFn, componentClass, storeNames.join("-"));
    };
  }
}

var mobxAdminProperty = mobx__WEBPACK_IMPORTED_MODULE_0__["$mobx"] || "$mobx";
/**
 * dev tool support
 */

var isDevtoolsEnabled = false;
var isUsingStaticRendering = false;
var warnedAboutObserverInjectDeprecation = false; // WeakMap<Node, Object>;

var componentByNodeRegistry = typeof WeakMap !== "undefined" ? new WeakMap() : undefined;
var renderReporter = new EventEmitter();
var createdSymbols = {};

function createRealSymbol(name) {
  if (typeof Symbol === "function") {
    return Symbol(name);
  }

  return "$mobxReactProp$" + name + Math.random();
}

function createSymbol(name) {
  if (!createdSymbols[name]) {
    createdSymbols[name] = createRealSymbol(name);
  }

  return createdSymbols[name];
}

var skipRenderKey = createSymbol("skipRender");
var isForcingUpdateKey = createSymbol("isForcingUpdate");
/**
 * Helper to set `prop` to `this` as non-enumerable (hidden prop)
 * @param target
 * @param prop
 * @param value
 */

function setHiddenProp(target, prop, value) {
  if (!Object.hasOwnProperty.call(target, prop)) {
    Object.defineProperty(target, prop, {
      enumerable: false,
      configurable: true,
      writable: true,
      value: value
    });
  } else {
    target[prop] = value;
  }
}

function findDOMNode$2(component) {
  if (react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"]) {
    try {
      return Object(react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"])(component);
    } catch (e) {
      // findDOMNode will throw in react-test-renderer, see:
      // See https://github.com/mobxjs/mobx-react/issues/216
      // Is there a better heuristic?
      return null;
    }
  }

  return null;
}

function reportRendering(component) {
  var node = findDOMNode$2(component);
  if (node && componentByNodeRegistry) componentByNodeRegistry.set(node, component);
  renderReporter.emit({
    event: "render",
    renderTime: component.__$mobRenderEnd - component.__$mobRenderStart,
    totalTime: Date.now() - component.__$mobRenderStart,
    component: component,
    node: node
  });
}

function trackComponents() {
  if (typeof WeakMap === "undefined") throw new Error("[mobx-react] tracking components is not supported in this browser.");
  if (!isDevtoolsEnabled) isDevtoolsEnabled = true;
}

function useStaticRendering(useStaticRendering) {
  isUsingStaticRendering = useStaticRendering;
}
/**
 * Errors reporter
 */


var errorsReporter = new EventEmitter();
/**
 * Utilities
 */

function patch(target, funcName) {
  var runMixinFirst = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  var base = target[funcName];
  var mixinFunc = reactiveMixin[funcName];
  var f = !base ? mixinFunc : runMixinFirst === true ? function () {
    mixinFunc.apply(this, arguments);
    base.apply(this, arguments);
  } : function () {
    base.apply(this, arguments);
    mixinFunc.apply(this, arguments);
  }; // MWE: ideally we freeze here to protect against accidental overwrites in component instances, see #195
  // ...but that breaks react-hot-loader, see #231...

  target[funcName] = f;
}

function shallowEqual(objA, objB) {
  //From: https://github.com/facebook/fbjs/blob/c69904a511b900266935168223063dd8772dfc40/packages/fbjs/src/core/shallowEqual.js
  if (is(objA, objB)) return true;

  if ((typeof objA === "undefined" ? "undefined" : _typeof(objA)) !== "object" || objA === null || (typeof objB === "undefined" ? "undefined" : _typeof(objB)) !== "object" || objB === null) {
    return false;
  }

  var keysA = Object.keys(objA);
  var keysB = Object.keys(objB);
  if (keysA.length !== keysB.length) return false;

  for (var i = 0; i < keysA.length; i++) {
    if (!hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) {
      return false;
    }
  }

  return true;
}

function is(x, y) {
  // From: https://github.com/facebook/fbjs/blob/c69904a511b900266935168223063dd8772dfc40/packages/fbjs/src/core/shallowEqual.js
  if (x === y) {
    return x !== 0 || 1 / x === 1 / y;
  } else {
    return x !== x && y !== y;
  }
}

function makeComponentReactive(render) {
  var _this2 = this;

  if (isUsingStaticRendering === true) return render.call(this);

  function reactiveRender() {
    var _this = this;

    isRenderingPending = false;
    var exception = undefined;
    var rendering = undefined;
    reaction.track(function () {
      if (isDevtoolsEnabled) {
        _this.__$mobRenderStart = Date.now();
      }

      try {
        rendering = Object(mobx__WEBPACK_IMPORTED_MODULE_0__["_allowStateChanges"])(false, baseRender);
      } catch (e) {
        exception = e;
      }

      if (isDevtoolsEnabled) {
        _this.__$mobRenderEnd = Date.now();
      }
    });

    if (exception) {
      errorsReporter.emit(exception);
      throw exception;
    }

    return rendering;
  } // Generate friendly name for debugging


  var initialName = this.displayName || this.name || this.constructor && (this.constructor.displayName || this.constructor.name) || "<component>";
  var rootNodeID = this._reactInternalInstance && this._reactInternalInstance._rootNodeID || this._reactInternalInstance && this._reactInternalInstance._debugID || this._reactInternalFiber && this._reactInternalFiber._debugID;
  /**
   * If props are shallowly modified, react will render anyway,
   * so atom.reportChanged() should not result in yet another re-render
   */

  setHiddenProp(this, skipRenderKey, false);
  /**
   * forceUpdate will re-assign this.props. We don't want that to cause a loop,
   * so detect these changes
   */

  setHiddenProp(this, isForcingUpdateKey, false); // wire up reactive render

  var baseRender = render.bind(this);
  var isRenderingPending = false;
  var reaction = new mobx__WEBPACK_IMPORTED_MODULE_0__["Reaction"](initialName + "#" + rootNodeID + ".render()", function () {
    if (!isRenderingPending) {
      // N.B. Getting here *before mounting* means that a component constructor has side effects (see the relevant test in misc.js)
      // This unidiomatic React usage but React will correctly warn about this so we continue as usual
      // See #85 / Pull #44
      isRenderingPending = true;
      if (typeof _this2.componentWillReact === "function") _this2.componentWillReact(); // TODO: wrap in action?

      if (_this2.__$mobxIsUnmounted !== true) {
        // If we are unmounted at this point, componentWillReact() had a side effect causing the component to unmounted
        // TODO: remove this check? Then react will properly warn about the fact that this should not happen? See #73
        // However, people also claim this migth happen during unit tests..
        var hasError = true;

        try {
          setHiddenProp(_this2, isForcingUpdateKey, true);
          if (!_this2[skipRenderKey]) react__WEBPACK_IMPORTED_MODULE_1__["Component"].prototype.forceUpdate.call(_this2);
          hasError = false;
        } finally {
          setHiddenProp(_this2, isForcingUpdateKey, false);
          if (hasError) reaction.dispose();
        }
      }
    }
  });
  reaction.reactComponent = this;
  reactiveRender[mobxAdminProperty] = reaction;
  this.render = reactiveRender;
  return reactiveRender.call(this);
}
/**
 * ReactiveMixin
 */


var reactiveMixin = {
  componentWillUnmount: function componentWillUnmount() {
    if (isUsingStaticRendering === true) return;
    this.render[mobxAdminProperty] && this.render[mobxAdminProperty].dispose();
    this.__$mobxIsUnmounted = true;

    if (isDevtoolsEnabled) {
      var node = findDOMNode$2(this);

      if (node && componentByNodeRegistry) {
        componentByNodeRegistry.delete(node);
      }

      renderReporter.emit({
        event: "destroy",
        component: this,
        node: node
      });
    }
  },
  componentDidMount: function componentDidMount() {
    if (isDevtoolsEnabled) {
      reportRendering(this);
    }
  },
  componentDidUpdate: function componentDidUpdate() {
    if (isDevtoolsEnabled) {
      reportRendering(this);
    }
  },
  shouldComponentUpdate: function shouldComponentUpdate(nextProps, nextState) {
    if (isUsingStaticRendering) {
      console.warn("[mobx-react] It seems that a re-rendering of a React component is triggered while in static (server-side) mode. Please make sure components are rendered only once server-side.");
    } // update on any state changes (as is the default)


    if (this.state !== nextState) {
      return true;
    } // update if props are shallowly not equal, inspired by PureRenderMixin
    // we could return just 'false' here, and avoid the `skipRender` checks etc
    // however, it is nicer if lifecycle events are triggered like usually,
    // so we return true here if props are shallowly modified.


    return !shallowEqual(this.props, nextProps);
  }
};

function makeObservableProp(target, propName) {
  var valueHolderKey = createSymbol(propName + " value holder");
  var atomHolderKey = createSymbol(propName + " atom holder");

  function getAtom() {
    if (!this[atomHolderKey]) {
      setHiddenProp(this, atomHolderKey, Object(mobx__WEBPACK_IMPORTED_MODULE_0__["createAtom"])("reactive " + propName));
    }

    return this[atomHolderKey];
  }

  Object.defineProperty(target, propName, {
    configurable: true,
    enumerable: true,
    get: function get$$1() {
      getAtom.call(this).reportObserved();
      return this[valueHolderKey];
    },
    set: function set$$1(v) {
      if (!this[isForcingUpdateKey] && !shallowEqual(this[valueHolderKey], v)) {
        setHiddenProp(this, valueHolderKey, v);
        setHiddenProp(this, skipRenderKey, true);
        getAtom.call(this).reportChanged();
        setHiddenProp(this, skipRenderKey, false);
      } else {
        setHiddenProp(this, valueHolderKey, v);
      }
    }
  });
}
/**
 * Observer function / decorator
 */


function observer(arg1, arg2) {
  if (typeof arg1 === "string") {
    throw new Error("Store names should be provided as array");
  }

  if (Array.isArray(arg1)) {
    // TODO: remove in next major
    // component needs stores
    if (!warnedAboutObserverInjectDeprecation) {
      warnedAboutObserverInjectDeprecation = true;
      console.warn('Mobx observer: Using observer to inject stores is deprecated since 4.0. Use `@inject("store1", "store2") @observer ComponentClass` or `inject("store1", "store2")(observer(componentClass))` instead of `@observer(["store1", "store2"]) ComponentClass`');
    }

    if (!arg2) {
      // invoked as decorator
      return function (componentClass) {
        return observer(arg1, componentClass);
      };
    } else {
      return inject.apply(null, arg1)(observer(arg2));
    }
  }

  var componentClass = arg1;

  if (componentClass.isMobxInjector === true) {
    console.warn("Mobx observer: You are trying to use 'observer' on a component that already has 'inject'. Please apply 'observer' before applying 'inject'");
  }

  if (componentClass.__proto__ === react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]) {
    console.warn("Mobx observer: You are using 'observer' on React.PureComponent. These two achieve two opposite goals and should not be used together");
  } // Stateless function component:
  // If it is function but doesn't seem to be a react class constructor,
  // wrap it to a react class automatically


  if (typeof componentClass === "function" && (!componentClass.prototype || !componentClass.prototype.render) && !componentClass.isReactClass && !react__WEBPACK_IMPORTED_MODULE_1__["Component"].isPrototypeOf(componentClass)) {
    var _class, _temp;

    var observerComponent = observer((_temp = _class = function (_Component) {
      inherits(_class, _Component);

      function _class() {
        classCallCheck(this, _class);
        return possibleConstructorReturn(this, (_class.__proto__ || Object.getPrototypeOf(_class)).apply(this, arguments));
      }

      createClass(_class, [{
        key: "render",
        value: function render() {
          return componentClass.call(this, this.props, this.context);
        }
      }]);
      return _class;
    }(react__WEBPACK_IMPORTED_MODULE_1__["Component"]), _class.displayName = componentClass.displayName || componentClass.name, _class.contextTypes = componentClass.contextTypes, _class.propTypes = componentClass.propTypes, _class.defaultProps = componentClass.defaultProps, _temp));
    hoistNonReactStatics_cjs(observerComponent, componentClass);
    return observerComponent;
  }

  if (!componentClass) {
    throw new Error("Please pass a valid component to 'observer'");
  }

  var target = componentClass.prototype || componentClass;
  mixinLifecycleEvents(target);
  componentClass.isMobXReactObserver = true;
  makeObservableProp(target, "props");
  makeObservableProp(target, "state");
  var baseRender = target.render;

  target.render = function () {
    return makeComponentReactive.call(this, baseRender);
  };

  return componentClass;
}

function mixinLifecycleEvents(target) {
  ["componentDidMount", "componentWillUnmount", "componentDidUpdate"].forEach(function (funcName) {
    patch(target, funcName);
  });

  if (!target.shouldComponentUpdate) {
    target.shouldComponentUpdate = reactiveMixin.shouldComponentUpdate;
  } else {
    if (target.shouldComponentUpdate !== reactiveMixin.shouldComponentUpdate) {
      // TODO: make throw in next major
      console.warn("Use `shouldComponentUpdate` in an `observer` based component breaks the behavior of `observer` and might lead to unexpected results. Manually implementing `sCU` should not be needed when using mobx-react.");
    }
  }
}

var Observer = observer(function (_ref) {
  var children = _ref.children,
      observerInject = _ref.inject,
      render = _ref.render;
  var component = children || render;

  if (typeof component === "undefined") {
    return null;
  }

  if (!observerInject) {
    return component();
  } // TODO: remove in next major


  console.warn("<Observer inject=.../> is no longer supported. Please use inject on the enclosing component instead");
  var InjectComponent = inject(observerInject)(component);
  return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(InjectComponent, null);
});
Observer.displayName = "Observer";

var ObserverPropsCheck = function ObserverPropsCheck(props, key, componentName, location, propFullName) {
  var extraKey = key === "children" ? "render" : "children";

  if (typeof props[key] === "function" && typeof props[extraKey] === "function") {
    return new Error("Invalid prop,do not use children and render in the same time in`" + componentName);
  }

  if (typeof props[key] === "function" || typeof props[extraKey] === "function") {
    return;
  }

  return new Error("Invalid prop `" + propFullName + "` of type `" + _typeof(props[key]) + "` supplied to" + " `" + componentName + "`, expected `function`.");
};

Observer.propTypes = {
  render: ObserverPropsCheck,
  children: ObserverPropsCheck
};
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

function componentWillMount() {
  // Call this.constructor.gDSFP to support sub-classes.
  var state = this.constructor.getDerivedStateFromProps(this.props, this.state);

  if (state !== null && state !== undefined) {
    this.setState(state);
  }
}

function componentWillReceiveProps(nextProps) {
  // Call this.constructor.gDSFP to support sub-classes.
  // Use the setState() updater to ensure state isn't stale in certain edge cases.
  function updater(prevState) {
    var state = this.constructor.getDerivedStateFromProps(nextProps, prevState);
    return state !== null && state !== undefined ? state : null;
  } // Binding "this" is important for shallow renderer support.


  this.setState(updater.bind(this));
}

function componentWillUpdate(nextProps, nextState) {
  try {
    var prevProps = this.props;
    var prevState = this.state;
    this.props = nextProps;
    this.state = nextState;
    this.__reactInternalSnapshotFlag = true;
    this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(prevProps, prevState);
  } finally {
    this.props = prevProps;
    this.state = prevState;
  }
} // React may warn about cWM/cWRP/cWU methods being deprecated.
// Add a flag to suppress these warnings for this special case.


componentWillMount.__suppressDeprecationWarning = true;
componentWillReceiveProps.__suppressDeprecationWarning = true;
componentWillUpdate.__suppressDeprecationWarning = true;

function polyfill(Component$$1) {
  var prototype = Component$$1.prototype;

  if (!prototype || !prototype.isReactComponent) {
    throw new Error('Can only polyfill class components');
  }

  if (typeof Component$$1.getDerivedStateFromProps !== 'function' && typeof prototype.getSnapshotBeforeUpdate !== 'function') {
    return Component$$1;
  } // If new component APIs are defined, "unsafe" lifecycles won't be called.
  // Error if any of these lifecycles are present,
  // Because they would work differently between older and newer (16.3+) versions of React.


  var foundWillMountName = null;
  var foundWillReceivePropsName = null;
  var foundWillUpdateName = null;

  if (typeof prototype.componentWillMount === 'function') {
    foundWillMountName = 'componentWillMount';
  } else if (typeof prototype.UNSAFE_componentWillMount === 'function') {
    foundWillMountName = 'UNSAFE_componentWillMount';
  }

  if (typeof prototype.componentWillReceiveProps === 'function') {
    foundWillReceivePropsName = 'componentWillReceiveProps';
  } else if (typeof prototype.UNSAFE_componentWillReceiveProps === 'function') {
    foundWillReceivePropsName = 'UNSAFE_componentWillReceiveProps';
  }

  if (typeof prototype.componentWillUpdate === 'function') {
    foundWillUpdateName = 'componentWillUpdate';
  } else if (typeof prototype.UNSAFE_componentWillUpdate === 'function') {
    foundWillUpdateName = 'UNSAFE_componentWillUpdate';
  }

  if (foundWillMountName !== null || foundWillReceivePropsName !== null || foundWillUpdateName !== null) {
    var componentName = Component$$1.displayName || Component$$1.name;
    var newApiName = typeof Component$$1.getDerivedStateFromProps === 'function' ? 'getDerivedStateFromProps()' : 'getSnapshotBeforeUpdate()';
    throw Error('Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n' + componentName + ' uses ' + newApiName + ' but also contains the following legacy lifecycles:' + (foundWillMountName !== null ? '\n  ' + foundWillMountName : '') + (foundWillReceivePropsName !== null ? '\n  ' + foundWillReceivePropsName : '') + (foundWillUpdateName !== null ? '\n  ' + foundWillUpdateName : '') + '\n\nThe above lifecycles should be removed. Learn more about this warning here:\n' + 'https://fb.me/react-async-component-lifecycle-hooks');
  } // React <= 16.2 does not support static getDerivedStateFromProps.
  // As a workaround, use cWM and cWRP to invoke the new static lifecycle.
  // Newer versions of React will ignore these lifecycles if gDSFP exists.


  if (typeof Component$$1.getDerivedStateFromProps === 'function') {
    prototype.componentWillMount = componentWillMount;
    prototype.componentWillReceiveProps = componentWillReceiveProps;
  } // React <= 16.2 does not support getSnapshotBeforeUpdate.
  // As a workaround, use cWU to invoke the new lifecycle.
  // Newer versions of React will ignore that lifecycle if gSBU exists.


  if (typeof prototype.getSnapshotBeforeUpdate === 'function') {
    if (typeof prototype.componentDidUpdate !== 'function') {
      throw new Error('Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype');
    }

    prototype.componentWillUpdate = componentWillUpdate;
    var componentDidUpdate = prototype.componentDidUpdate;

    prototype.componentDidUpdate = function componentDidUpdatePolyfill(prevProps, prevState, maybeSnapshot) {
      // 16.3+ will not execute our will-update method;
      // It will pass a snapshot value to did-update though.
      // Older versions will require our polyfilled will-update value.
      // We need to handle both cases, but can't just check for the presence of "maybeSnapshot",
      // Because for <= 15.x versions this might be a "prevContext" object.
      // We also can't just check "__reactInternalSnapshot",
      // Because get-snapshot might return a falsy value.
      // So check for the explicit __reactInternalSnapshotFlag flag to determine behavior.
      var snapshot = this.__reactInternalSnapshotFlag ? this.__reactInternalSnapshot : maybeSnapshot;
      componentDidUpdate.call(this, prevProps, prevState, snapshot);
    };
  }

  return Component$$1;
}

var _class;

var _temp;

var specialReactKeys = {
  children: true,
  key: true,
  ref: true
};
var Provider = (_temp = _class = function (_Component) {
  inherits(Provider, _Component);

  function Provider(props, context) {
    classCallCheck(this, Provider);

    var _this = possibleConstructorReturn(this, (Provider.__proto__ || Object.getPrototypeOf(Provider)).call(this, props, context));

    _this.state = {};
    copyStores(props, _this.state);
    return _this;
  }

  createClass(Provider, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_1__["Children"].only(this.props.children);
    }
  }, {
    key: "getChildContext",
    value: function getChildContext() {
      var stores = {}; // inherit stores

      copyStores(this.context.mobxStores, stores); // add own stores

      copyStores(this.props, stores);
      return {
        mobxStores: stores
      };
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(nextProps, prevState) {
      if (!nextProps) return null;
      if (!prevState) return nextProps; // Maybe this warning is too aggressive?

      if (Object.keys(nextProps).filter(validStoreName).length !== Object.keys(prevState).filter(validStoreName).length) console.warn("MobX Provider: The set of provided stores has changed. Please avoid changing stores as the change might not propagate to all children");
      if (!nextProps.suppressChangedStoreWarning) for (var key in nextProps) {
        if (validStoreName(key) && prevState[key] !== nextProps[key]) console.warn("MobX Provider: Provided store '" + key + "' has changed. Please avoid replacing stores as the change might not propagate to all children");
      }
      return nextProps;
    }
  }]);
  return Provider;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]), _class.contextTypes = {
  mobxStores: objectOrObservableObject
}, _class.childContextTypes = {
  mobxStores: objectOrObservableObject.isRequired
}, _temp);

function copyStores(from, to) {
  if (!from) return;

  for (var key in from) {
    if (validStoreName(key)) to[key] = from[key];
  }
}

function validStoreName(key) {
  return !specialReactKeys[key] && key !== "suppressChangedStoreWarning";
} // TODO: kill in next major


polyfill(Provider);
if (!react__WEBPACK_IMPORTED_MODULE_1__["Component"]) throw new Error("mobx-react requires React to be available");
if (!mobx__WEBPACK_IMPORTED_MODULE_0__["spy"]) throw new Error("mobx-react requires mobx to be available");
if (typeof react_dom__WEBPACK_IMPORTED_MODULE_2__["unstable_batchedUpdates"] === "function") Object(mobx__WEBPACK_IMPORTED_MODULE_0__["configure"])({
  reactionScheduler: react_dom__WEBPACK_IMPORTED_MODULE_2__["unstable_batchedUpdates"]
});else if (typeof unstable_batchedUpdates$1 === "function") Object(mobx__WEBPACK_IMPORTED_MODULE_0__["configure"])({
  reactionScheduler: unstable_batchedUpdates$1
});

var onError = function onError(fn) {
  return errorsReporter.on(fn);
};
/* DevTool support */
// See: https://github.com/andykog/mobx-devtools/blob/d8976c24b8cb727ed59f9a0bc905a009df79e221/src/backend/installGlobalHook.js


if ((typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ === "undefined" ? "undefined" : _typeof(__MOBX_DEVTOOLS_GLOBAL_HOOK__)) === "object") {
  var mobx$1 = {
    spy: mobx__WEBPACK_IMPORTED_MODULE_0__["spy"],
    extras: {
      getDebugName: mobx__WEBPACK_IMPORTED_MODULE_0__["getDebugName"]
    }
  };
  var mobxReact = {
    renderReporter: renderReporter,
    componentByNodeRegistry: componentByNodeRegistry,
    componentByNodeRegistery: componentByNodeRegistry,
    trackComponents: trackComponents
  };

  __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobxReact(mobxReact, mobx$1);
}



/***/ }),

/***/ "./node_modules/process/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/process/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {}; // cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
  throw new Error('setTimeout has not been defined');
}

function defaultClearTimeout() {
  throw new Error('clearTimeout has not been defined');
}

(function () {
  try {
    if (typeof setTimeout === 'function') {
      cachedSetTimeout = setTimeout;
    } else {
      cachedSetTimeout = defaultSetTimout;
    }
  } catch (e) {
    cachedSetTimeout = defaultSetTimout;
  }

  try {
    if (typeof clearTimeout === 'function') {
      cachedClearTimeout = clearTimeout;
    } else {
      cachedClearTimeout = defaultClearTimeout;
    }
  } catch (e) {
    cachedClearTimeout = defaultClearTimeout;
  }
})();

function runTimeout(fun) {
  if (cachedSetTimeout === setTimeout) {
    //normal enviroments in sane situations
    return setTimeout(fun, 0);
  } // if setTimeout wasn't available but was latter defined


  if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
    cachedSetTimeout = setTimeout;
    return setTimeout(fun, 0);
  }

  try {
    // when when somebody has screwed with setTimeout but no I.E. maddness
    return cachedSetTimeout(fun, 0);
  } catch (e) {
    try {
      // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
      return cachedSetTimeout.call(null, fun, 0);
    } catch (e) {
      // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
      return cachedSetTimeout.call(this, fun, 0);
    }
  }
}

function runClearTimeout(marker) {
  if (cachedClearTimeout === clearTimeout) {
    //normal enviroments in sane situations
    return clearTimeout(marker);
  } // if clearTimeout wasn't available but was latter defined


  if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
    cachedClearTimeout = clearTimeout;
    return clearTimeout(marker);
  }

  try {
    // when when somebody has screwed with setTimeout but no I.E. maddness
    return cachedClearTimeout(marker);
  } catch (e) {
    try {
      // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
      return cachedClearTimeout.call(null, marker);
    } catch (e) {
      // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
      // Some versions of I.E. have different rules for clearTimeout vs setTimeout
      return cachedClearTimeout.call(this, marker);
    }
  }
}

var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
  if (!draining || !currentQueue) {
    return;
  }

  draining = false;

  if (currentQueue.length) {
    queue = currentQueue.concat(queue);
  } else {
    queueIndex = -1;
  }

  if (queue.length) {
    drainQueue();
  }
}

function drainQueue() {
  if (draining) {
    return;
  }

  var timeout = runTimeout(cleanUpNextTick);
  draining = true;
  var len = queue.length;

  while (len) {
    currentQueue = queue;
    queue = [];

    while (++queueIndex < len) {
      if (currentQueue) {
        currentQueue[queueIndex].run();
      }
    }

    queueIndex = -1;
    len = queue.length;
  }

  currentQueue = null;
  draining = false;
  runClearTimeout(timeout);
}

process.nextTick = function (fun) {
  var args = new Array(arguments.length - 1);

  if (arguments.length > 1) {
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
  }

  queue.push(new Item(fun, args));

  if (queue.length === 1 && !draining) {
    runTimeout(drainQueue);
  }
}; // v8 likes predictible objects


function Item(fun, array) {
  this.fun = fun;
  this.array = array;
}

Item.prototype.run = function () {
  this.fun.apply(null, this.array);
};

process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues

process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) {
  return [];
};

process.binding = function (name) {
  throw new Error('process.binding is not supported');
};

process.cwd = function () {
  return '/';
};

process.chdir = function (dir) {
  throw new Error('process.chdir is not supported');
};

process.umask = function () {
  return 0;
};

/***/ }),

/***/ "./node_modules/react-aiot/src/style/theme-wordpress.scss":
/*!****************************************************************!*\
  !*** ./node_modules/react-aiot/src/style/theme-wordpress.scss ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./node_modules/setimmediate/setImmediate.js":
/*!***************************************************!*\
  !*** ./node_modules/setimmediate/setImmediate.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global, process) {(function (global, undefined) {
  "use strict";

  if (global.setImmediate) {
    return;
  }

  var nextHandle = 1; // Spec says greater than zero

  var tasksByHandle = {};
  var currentlyRunningATask = false;
  var doc = global.document;
  var registerImmediate;

  function setImmediate(callback) {
    // Callback can either be a function or a string
    if (typeof callback !== "function") {
      callback = new Function("" + callback);
    } // Copy function arguments


    var args = new Array(arguments.length - 1);

    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i + 1];
    } // Store and register the task


    var task = {
      callback: callback,
      args: args
    };
    tasksByHandle[nextHandle] = task;
    registerImmediate(nextHandle);
    return nextHandle++;
  }

  function clearImmediate(handle) {
    delete tasksByHandle[handle];
  }

  function run(task) {
    var callback = task.callback;
    var args = task.args;

    switch (args.length) {
      case 0:
        callback();
        break;

      case 1:
        callback(args[0]);
        break;

      case 2:
        callback(args[0], args[1]);
        break;

      case 3:
        callback(args[0], args[1], args[2]);
        break;

      default:
        callback.apply(undefined, args);
        break;
    }
  }

  function runIfPresent(handle) {
    // From the spec: "Wait until any invocations of this algorithm started before this one have completed."
    // So if we're currently running a task, we'll need to delay this invocation.
    if (currentlyRunningATask) {
      // Delay by doing a setTimeout. setImmediate was tried instead, but in Firefox 7 it generated a
      // "too much recursion" error.
      setTimeout(runIfPresent, 0, handle);
    } else {
      var task = tasksByHandle[handle];

      if (task) {
        currentlyRunningATask = true;

        try {
          run(task);
        } finally {
          clearImmediate(handle);
          currentlyRunningATask = false;
        }
      }
    }
  }

  function installNextTickImplementation() {
    registerImmediate = function (handle) {
      process.nextTick(function () {
        runIfPresent(handle);
      });
    };
  }

  function canUsePostMessage() {
    // The test against `importScripts` prevents this implementation from being installed inside a web worker,
    // where `global.postMessage` means something completely different and can't be used for this purpose.
    if (global.postMessage && !global.importScripts) {
      var postMessageIsAsynchronous = true;
      var oldOnMessage = global.onmessage;

      global.onmessage = function () {
        postMessageIsAsynchronous = false;
      };

      global.postMessage("", "*");
      global.onmessage = oldOnMessage;
      return postMessageIsAsynchronous;
    }
  }

  function installPostMessageImplementation() {
    // Installs an event handler on `global` for the `message` event: see
    // * https://developer.mozilla.org/en/DOM/window.postMessage
    // * http://www.whatwg.org/specs/web-apps/current-work/multipage/comms.html#crossDocumentMessages
    var messagePrefix = "setImmediate$" + Math.random() + "$";

    var onGlobalMessage = function (event) {
      if (event.source === global && typeof event.data === "string" && event.data.indexOf(messagePrefix) === 0) {
        runIfPresent(+event.data.slice(messagePrefix.length));
      }
    };

    if (global.addEventListener) {
      global.addEventListener("message", onGlobalMessage, false);
    } else {
      global.attachEvent("onmessage", onGlobalMessage);
    }

    registerImmediate = function (handle) {
      global.postMessage(messagePrefix + handle, "*");
    };
  }

  function installMessageChannelImplementation() {
    var channel = new MessageChannel();

    channel.port1.onmessage = function (event) {
      var handle = event.data;
      runIfPresent(handle);
    };

    registerImmediate = function (handle) {
      channel.port2.postMessage(handle);
    };
  }

  function installReadyStateChangeImplementation() {
    var html = doc.documentElement;

    registerImmediate = function (handle) {
      // Create a <script> element; its readystatechange event will be fired asynchronously once it is inserted
      // into the document. Do so, thus queuing up the task. Remember to clean up once it's been called.
      var script = doc.createElement("script");

      script.onreadystatechange = function () {
        runIfPresent(handle);
        script.onreadystatechange = null;
        html.removeChild(script);
        script = null;
      };

      html.appendChild(script);
    };
  }

  function installSetTimeoutImplementation() {
    registerImmediate = function (handle) {
      setTimeout(runIfPresent, 0, handle);
    };
  } // If supported, we should attach to the prototype of global, since that is where setTimeout et al. live.


  var attachTo = Object.getPrototypeOf && Object.getPrototypeOf(global);
  attachTo = attachTo && attachTo.setTimeout ? attachTo : global; // Don't get fooled by e.g. browserify environments.

  if ({}.toString.call(global.process) === "[object process]") {
    // For Node.js before 0.9
    installNextTickImplementation();
  } else if (canUsePostMessage()) {
    // For non-IE10 modern browsers
    installPostMessageImplementation();
  } else if (global.MessageChannel) {
    // For web workers, where supported
    installMessageChannelImplementation();
  } else if (doc && "onreadystatechange" in doc.createElement("script")) {
    // For IE 6–8
    installReadyStateChangeImplementation();
  } else {
    // For older browsers
    installSetTimeoutImplementation();
  }

  attachTo.setImmediate = setImmediate;
  attachTo.clearImmediate = clearImmediate;
})(typeof self === "undefined" ? typeof global === "undefined" ? this : global : self);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js"), __webpack_require__(/*! ./../process/browser.js */ "./node_modules/process/browser.js")))

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g; // This works in non-strict mode

g = function () {
  return this;
}();

try {
  // This works if eval is allowed (see CSP)
  g = g || Function("return this")() || (1, eval)("this");
} catch (e) {
  // This works if the window reference is available
  if (typeof window === "object") g = window;
} // g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}


module.exports = g;

/***/ }),

/***/ "./public/src/AppTree.js":
/*!*******************************!*\
  !*** ./public/src/AppTree.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AppTree; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components */ "./public/src/components/index.js");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./util */ "./public/src/util/index.js");
/* harmony import */ var _util_dragdrop__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./util/dragdrop */ "./public/src/util/dragdrop.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! mobx-react */ "./node_modules/mobx-react/index.module.js");


var _dec, _class2;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/** @module AppTree */









react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].config({
  top: 50
});
/**
 * The application tree handler for Real Categories Management.
 * 
 * @param {string} typenow The current post type
 * @param {string} taxnow The current taxonomy
 * @param {object} taxos Key value map of available taxonomies
 * @param {boolean} isFastMode If true the fast mode content is activated
 * @param {string} id The HTML id (needed to localStorage support)
 * @extends React.Component
 */

var AppTree = (_dec = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["inject"])('store'), _dec(_class2 = Object(mobx_react__WEBPACK_IMPORTED_MODULE_8__["observer"])(_class2 =
/*#__PURE__*/
function (_React$Component) {
  _inherits(AppTree, _React$Component);

  /**
   * Initialize properties and state for AIOTree component.
   * Also handles the responsiveness.
   */
  function AppTree(_props) {
    var _this;

    _classCallCheck(this, AppTree);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(AppTree).call(this, _props)); // Add respnsive handler

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "renderToolbarButtons", function () {
      var _this$state = _this.state,
          availableToolbarButtons = _this$state.availableToolbarButtons,
          toolbarBackButton = _this$state.toolbarBackButton,
          toolbar = {
        buttons: {},
        backButton: _this.resolveStateRefs(toolbarBackButton, 'keysToolbar')
      };

      for (var i = 0; i < availableToolbarButtons.length; i++) {
        toolbar.buttons[availableToolbarButtons[i]] = _this.resolveStateRefs(_this.state['toolbar_' + availableToolbarButtons[i]], 'keysToolbar');
      }

      return toolbar;
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "renderCreatables", function () {
      var _this$state2 = _this.state,
          availableCreatables = _this$state2.availableCreatables,
          creatableBackButton = _this$state2.creatableBackButton,
          creatable = {
        buttons: {},
        backButton: _this.resolveStateRefs(creatableBackButton, 'keysCreatable')
      };

      for (var i = 0; i < availableCreatables.length; i++) {
        creatable.buttons[availableCreatables[i]] = _this.resolveStateRefs(_this.state['creatable_' + availableCreatables[i]], 'keysCreatable');
      }

      return creatable;
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleCreatableClick", function (type) {
      var createRoot = undefined,
          $create = undefined;

      if (type) {
        // Activate create
        var newNode = {
          $rename: true,
          icon: _util__WEBPACK_IMPORTED_MODULE_5__["ICON_OBJ_FOLDER_OPEN"],
          parent: 0
        },
            selectedId = _this.getSelectedId();

        if (selectedId === 'ALL') {
          createRoot = newNode;
        } else {
          $create = newNode;
          newNode.parent = selectedId;
        }
      }

      _this.setState({
        isTreeLinkDisabled: !!type,
        isCreatableLinkCancel: !!type,
        isToolbarActive: !type,
        createRoot: createRoot
      });

      _this.updateTreeItemById(function (node) {
        node.$create = $create;
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSelect",
    /*#__PURE__*/
    function () {
      var _ref = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(id) {
        var url, node, setter;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(_this.state.toolbarActiveButton === 'sort')) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return");

              case 2:
                // Generate URL with query args
                url = window.location.href;

                if (id === 'ALL') {
                  url = Object(_util__WEBPACK_IMPORTED_MODULE_5__["addUrlParam"])(window.location.pathname, 'post_type', _this.state.typenow);
                } else {
                  node = _this.getTreeItemById(id);
                  jquery__WEBPACK_IMPORTED_MODULE_7___default.a.each(node.properties.queryArgs, function (key, value) {
                    url = Object(_util__WEBPACK_IMPORTED_MODULE_5__["addUrlParam"])(url, key, value);
                  });
                }

                +Object(_util__WEBPACK_IMPORTED_MODULE_5__["urlParam"])('paged') > 1 && (url = Object(_util__WEBPACK_IMPORTED_MODULE_5__["addUrlParam"])(url, 'paged', 1));

                setter = function setter(_id, $busy) {
                  _this.updateTreeItemById(function (node) {
                    node.selected = true;
                    node.$busy = $busy;
                  }, _id);

                  _this._updateToolbarButtons();
                }; // Check fast mode


                if (_this.props.isFastMode) {
                  // Load URL with fast mode and get the content
                  setter(id, false);
                  setTimeout(
                  /*#__PURE__*/
                  _asyncToGenerator(
                  /*#__PURE__*/
                  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
                    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            _context.next = 2;
                            return Object(_util__WEBPACK_IMPORTED_MODULE_5__["fastModeContent"])(url);

                          case 2:
                            Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["draggable"])();

                          case 3:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee, this);
                  })), 0);
                } else {
                  window.location.href = url;
                  setter(id, true);
                }

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleRenameClick", function () {
      return _this._handleRenameNode('rename', true, true, true);
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleRenameCancel", function () {
      return _this._handleRenameNode(undefined, false, false, undefined);
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleRenameClose",
    /*#__PURE__*/
    function () {
      var _ref3 = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(save, inputValue, _ref4) {
        var id, hide, _ref5, name;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                id = _ref4.id;

                if (!(save && inputValue.length)) {
                  _context3.next = 21;
                  break;
                }

                hide = react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].loading(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('renameLoadingText', {
                  name: inputValue
                }));
                _context3.prev = 3;
                _context3.next = 6;
                return _this.props.store.getTreeItemById(id).setName(inputValue);

              case 6:
                _ref5 = _context3.sent;
                name = _ref5.name;
                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].success(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('renameSuccess', {
                  name: name
                }));

                _this.handleRenameCancel();

                _context3.next = 16;
                break;

              case 12:
                _context3.prev = 12;
                _context3.t0 = _context3["catch"](3);
                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].error(_context3.t0.responseJSON.message);

                _this.updateTreeItemById(function (node) {
                  node.$busy = false;
                }, id);

              case 16:
                _context3.prev = 16;
                hide();
                return _context3.finish(16);

              case 19:
                _context3.next = 22;
                break;

              case 21:
                _this.handleRenameCancel();

              case 22:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[3, 12, 16, 19]]);
      }));

      return function (_x2, _x3, _x4) {
        return _ref3.apply(this, arguments);
      };
    }());

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleAddClose",
    /*#__PURE__*/
    function () {
      var _ref6 = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(save, name, _ref7) {
        var parent, hide;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                parent = _ref7.parent;

                if (!save) {
                  _context4.next = 21;
                  break;
                }

                _this.updateCreateNode(function (node) {
                  node.$busy = true;
                });

                hide = react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].loading(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('addLoadingText', {
                  name: name
                }));
                _context4.prev = 4;
                _context4.next = 7;
                return _this.props.store.persist({
                  name: name,
                  parent: parent,
                  type: _this.state.typenow,
                  taxonomy: _this.state.taxnow
                });

              case 7:
                _this.handleCreatableClick();

                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].success(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('addSuccess', {
                  name: name
                }));
                Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["droppable"])(_assertThisInitialized(_assertThisInitialized(_this)));
                _context4.next = 16;
                break;

              case 12:
                _context4.prev = 12;
                _context4.t0 = _context4["catch"](4);
                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].error(_context4.t0.responseJSON.message);

                _this.updateCreateNode(function (node) {
                  node.$busy = false;
                });

              case 16:
                _context4.prev = 16;
                hide();
                return _context4.finish(16);

              case 19:
                _context4.next = 22;
                break;

              case 21:
                _this.handleCreatableClick();

              case 22:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[4, 12, 16, 19]]);
      }));

      return function (_x5, _x6, _x7) {
        return _ref6.apply(this, arguments);
      };
    }());

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleTrash",
    /*#__PURE__*/
    _asyncToGenerator(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee5() {
      var node, hide, parentId;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              node = _this.getTreeItemById(); // Check if subdirectories

              if (!node.childNodes.length) {
                _context5.next = 3;
                break;
              }

              return _context5.abrupt("return", react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].error(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('deleteFailedSub', {
                name: node.title
              })));

            case 3:
              hide = react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].loading(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Deleteing ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("strong", null, node.title), "..."));
              _context5.prev = 4;
              _context5.next = 7;
              return node.trash();

            case 7:
              react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].success(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('deleteSuccess', {
                name: node.title
              })); // Select parent

              parentId = Object(react_aiot__WEBPACK_IMPORTED_MODULE_4__["getTreeParentById"])(node.id, _this.props.store.tree);

              _this.handleSelect(parentId === 0 ? 'ALL' : parentId);

              _context5.next = 15;
              break;

            case 12:
              _context5.prev = 12;
              _context5.t0 = _context5["catch"](4);
              react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].error(_context5.t0.responseJSON.message);

            case 15:
              _context5.prev = 15;
              hide();
              return _context5.finish(15);

            case 18:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5, this, [[4, 12, 15, 18]]);
    })));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSort",
    /*#__PURE__*/
    function () {
      var _ref9 = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee6(props) {
        var hide, _this$state3, toolbarActiveButton, typenow, taxnow, store;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _this.setState({
                  isSortableBusy: true,
                  isToolbarBusy: true
                });

                hide = react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].loading(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('sortLoadingText')), _this$state3 = _this.state, toolbarActiveButton = _this$state3.toolbarActiveButton, typenow = _this$state3.typenow, taxnow = _this$state3.taxnow, store = _this.props.store;
                _context6.prev = 2;
                _context6.next = 5;
                return store.handleSort(props, typenow, taxnow);

              case 5:
                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].success(Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('sortedSuccess'));
                _context6.next = 11;
                break;

              case 8:
                _context6.prev = 8;
                _context6.t0 = _context6["catch"](2);
                react_aiot__WEBPACK_IMPORTED_MODULE_4__["message"].error(_context6.t0.responseJSON.message);

              case 11:
                _context6.prev = 11;
                hide();

                _this._handleSortNode(toolbarActiveButton, false);

                return _context6.finish(11);

              case 15:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this, [[2, 8, 11, 15]]);
      }));

      return function (_x8) {
        return _ref9.apply(this, arguments);
      };
    }());

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleTaxSwitch", function (_ref10) {
      var key = _ref10.key;

      _this.setState({
        taxnow: key
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleWindowResize", function () {
      var isMobile = _this._isMobile();

      _this.setState({
        isSticky: !isMobile,
        isStickyHeader: !isMobile,
        isResizable: !isMobile,
        isFullWidth: isMobile,
        style: isMobile ? {
          marginLeft: 10
        } : {}
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleDismissLicenseNotice",
    /*#__PURE__*/
    _asyncToGenerator(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee7() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee7$(_context7) {
        while (1) {
          switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return Object(_util__WEBPACK_IMPORTED_MODULE_5__["ajax"])('notice/license', {
                method: 'DELETE'
              });

            case 2:
              window.location.reload();

            case 3:
            case "end":
              return _context7.stop();
          }
        }
      }, _callee7, this);
    })));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "onTreeNodeRender", function (createTreeNode, TreeNode, node) {
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_8__["Observer"], {
        key: node.id
      }, function () {
        return createTreeNode(node);
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "_handleRenameNode", function (toolbarActiveButton, isCreatableLinkDisabled, isTreeLinkDisabled, nodeRename) {
      _this.setState({
        // Make other nodes editable / not editable
        isCreatableLinkDisabled: isCreatableLinkDisabled,
        isTreeLinkDisabled: isTreeLinkDisabled,
        toolbarActiveButton: toolbarActiveButton
      });

      _this.updateTreeItemById(function (node) {
        // Make selected node editable / not editable
        node.$rename = nodeRename;
      });
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "_isMobile", function () {
      return jquery__WEBPACK_IMPORTED_MODULE_7___default()(window).width() <= 700;
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "_handleSortNode", function (toolbarActiveButton, isBusy) {
      _this.setState({
        isCreatableLinkDisabled: !!toolbarActiveButton,
        toolbarActiveButton: toolbarActiveButton,
        isSortableDisabled: !toolbarActiveButton,
        toolbarBackButton: Object.assign(_this.state.toolbarBackButton, {
          label: 'i18n.' + (toolbarActiveButton ? 'back' : 'cancel')
        })
      });

      typeof isBusy === 'boolean' && _this.setState({
        isSortableBusy: isBusy
      });
      typeof isBusy === 'boolean' && _this.setState({
        isToolbarBusy: isBusy
      });
    });

    jquery__WEBPACK_IMPORTED_MODULE_7___default()(window).resize(_this.handleWindowResize);

    var _isMobile = _this._isMobile();

    var _typenow = _props.typenow,
        _taxnow = _props.taxnow,
        taxos = _props.taxos; // State refs (see https://github.com/reactjs/redux/issues/1793) and #resolveStateRefs

    _this.stateRefs = {
      keysCreatable: 'icon,iconActive,toolTipTitle,toolTipText,onClick,label'.split(','),
      keysToolbar: 'content,toolTipTitle,toolTipText,onClick,onCancel,onSave,modifier,label,save'.split(','),
      // Icons
      ICON_OBJ_FOLDER_CLOSED: _util__WEBPACK_IMPORTED_MODULE_5__["ICON_OBJ_FOLDER_CLOSED"],
      ICON_OBJ_FOLDER_OPEN: _util__WEBPACK_IMPORTED_MODULE_5__["ICON_OBJ_FOLDER_OPEN"],
      ICON_FOLDER_ADD: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
        type: "folder-add"
      }),
      ICON_ORDER: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_3__["DashIcon"], {
        name: "move"
      }),
      ICON_RELOAD: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
        type: "reload"
      }),
      ICON_RENAME: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
        type: "edit"
      }),
      ICON_TRASH: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
        type: "delete"
      }),
      ICON_SORT: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_3__["DashIcon"], {
        name: "sort"
      }),
      ICON_SAVE: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
        type: "save"
      }),
      // Creatables
      handleCreatableClick: function handleCreatableClick() {
        return _this.handleCreatableClick('folder');
      },
      handleCreatableClickBackButton: function handleCreatableClickBackButton() {
        return _this.handleCreatableClick();
      },
      // Toolbar buttons
      handleOrderModifier: function handleOrderModifier(body) {
        // Install plugin
        !_util__WEBPACK_IMPORTED_MODULE_5__["rclOpts"].simplePageOrdering && !_util__WEBPACK_IMPORTED_MODULE_5__["isSortModeAvailable"] && (body = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Popconfirm"], {
          placement: "bottom",
          onConfirm: function onConfirm() {
            return window.location.href = _util__WEBPACK_IMPORTED_MODULE_5__["rclOpts"].simplePageOrderingLink;
          },
          title: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('installSimplePageOrdering', undefined, 'maxWidth'),
          okText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('installPlugin'),
          cancelText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('cancel')
        }, body));
        _util__WEBPACK_IMPORTED_MODULE_5__["rclOpts"].simplePageOrdering && !_util__WEBPACK_IMPORTED_MODULE_5__["isSortModeAvailable"] && (body = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Popconfirm"], {
          placement: "bottom",
          onConfirm: function onConfirm() {
            return window.open('https://wordpress.org/plugins/simple-page-ordering/#faq-header', '_blank');
          },
          title: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('noSimplePageOrdering', undefined, 'maxWidth'),
          okText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('learnMore'),
          cancelText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('cancel')
        }, body));
        return body;
      },
      handleOrderClick: function handleOrderClick() {
        _util__WEBPACK_IMPORTED_MODULE_5__["isSortModeAvailable"] && (window.location.href = _util__WEBPACK_IMPORTED_MODULE_5__["$byOrder"].find('a').attr('href'));
      },
      handleReload: function handleReload() {
        return window.location.reload();
      },
      handleRenameClick: _this.handleRenameClick,
      handleRenameCancel: _this.handleRenameCancel,
      handleTrashModifier: function handleTrashModifier(body) {
        var node = _this.getTreeItemById();

        return node ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Popconfirm"], {
          placement: "bottom",
          onConfirm: _this.handleTrash,
          title: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('deleteConfirm', {
            name: node.title
          }, 'maxWidth'),
          okText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('ok'),
          cancelText: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('cancel')
        }, body) : body;
      },
      handleSortClick: function handleSortClick() {
        return _this._handleSortNode('sort');
      },
      handleSortCancel: function handleSortCancel() {
        return _this._handleSortNode();
      }
    };
    _this.state = {
      // Custom
      typenow: _typenow,
      taxnow: _taxnow,
      taxos: taxos,
      createRoot: undefined,
      // Creatables
      availableCreatables: 'folder'.split(','),
      creatable_folder: {
        icon: 'ICON_FOLDER_ADD',
        cssClasses: 'page-title-action add-new-h2',
        toolTipTitle: 'i18n.creatableToolTipTitle',
        toolTipText: 'i18n.creatableToolTipText',
        label: 'i18n.new',
        onClick: 'handleCreatableClick'
      },
      creatableBackButton: {
        cssClasses: 'page-title-action add-new-h2',
        label: 'i18n.cancel',
        onClick: 'handleCreatableClickBackButton'
      },
      // Toolbar buttons
      availableToolbarButtons: 'order,reload,rename,trash,sort'.split(','),
      toolbar_order: {
        content: 'ICON_ORDER',
        toolTipTitle: 'i18n.orderToolTipTitle',
        toolTipText: 'i18n.orderToolTipText',
        modifier: 'handleOrderModifier',
        onClick: 'handleOrderClick'
      },
      toolbar_reload: {
        content: 'ICON_RELOAD',
        toolTipTitle: 'i18n.refreshToolTipTitle',
        toolTipText: 'i18n.refreshToolTipText',
        onClick: 'handleReload'
      },
      toolbar_rename: {
        content: 'ICON_RENAME',
        toolTipTitle: 'i18n.renameToolTipTitle',
        toolTipText: 'i18n.renameToolTipText',
        onClick: 'handleRenameClick',
        onCancel: 'handleRenameCancel',
        disabled: true
      },
      toolbar_trash: {
        content: 'ICON_TRASH',
        toolTipTitle: 'i18n.trashToolTipTitle',
        toolTipText: 'i18n.trashToolTipText',
        modifier: 'handleTrashModifier',
        disabled: true
      },
      toolbar_sort: {
        content: 'ICON_SORT',
        toolTipTitle: 'i18n.sortToolTipTitle',
        toolTipText: 'i18n.sortToolTipText',
        onClick: 'handleSortClick',
        onCancel: 'handleSortCancel'
      },
      toolbarBackButton: {
        label: 'i18n.cancel',
        save: 'i18n.save'
      },
      // AIO
      isResizable: !_isMobile,
      isSticky: !_isMobile,
      isStickyHeader: !_isMobile,
      isFullWidth: _isMobile,
      style: _isMobile ? {
        marginLeft: 10
      } : {},
      isSortable: true,
      isSortableDisabled: true,
      isTreeBusy: false,
      sortableDelay: 0,
      headerStickyAttr: {
        top: '#wpadminbar'
      },
      isCreatableLinkDisabled: false,
      toolbarActiveButton: undefined,
      isTreeLinkDisabled: false
    };
    return _this;
  }
  /**
   * Render AIO tree with tax switcher.
   */


  _createClass(AppTree, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var _this$state4 = this.state,
          typenow = _this$state4.typenow,
          taxnow = _this$state4.taxnow,
          taxos = _this$state4.taxos,
          methodMoved301Endpoint = _this$state4.methodMoved301Endpoint,
          taxSwitcherAttr = {
        typenow: typenow,
        taxnow: taxnow,
        taxos: taxos,
        methodMoved301Endpoint: methodMoved301Endpoint
      },
          _this$props$store = this.props.store,
          staticTree = _this$props$store.staticTree,
          tree = _this$props$store.tree,
          methodNotAllowed405Endpoint = _this$props$store.methodNotAllowed405Endpoint;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4___default.a, _extends({
        id: this.props.id,
        staticTree: staticTree,
        tree: tree.length > 0 ? tree : [],
        opposite: document.getElementById('wpbody-content'),
        onSelect: this.handleSelect,
        onRenameClose: this.handleRenameClose,
        onAddClose: this.handleAddClose,
        onNodePressF2: this.handleRenameClick,
        onSort: this.handleSort,
        onNodeExpand: function onNodeExpand() {
          return setTimeout(function () {
            return Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["droppable"])(_this2);
          }, 200);
        },
        renderItem: this.onTreeNodeRender,
        attr: {
          'data-type': typenow,
          'data-tax': taxnow
        },
        headline: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('categories', undefined, {
          style: {
            paddingRight: 5
          }
        }),
        renameSaveText: this.stateRefs.ICON_SAVE,
        renameAddText: this.stateRefs.ICON_SAVE,
        noFoldersTitle: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('noFoldersTitle'),
        noFoldersDescription: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('noFoldersDescription'),
        noSearchResult: Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('noSearchResult'),
        innerClassName: "wrap",
        theme: "wordpress",
        toolbar: this.renderToolbarButtons(),
        creatable: this.renderCreatables(),
        forceSortableFallback: true
      }, this.state), !!methodNotAllowed405Endpoint.length && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Alert"], {
        message: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('methodNotAllowed405', {
          endpoint: methodNotAllowed405Endpoint
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: "https://airbrake.io/blog/http-errors/405-method-not-allowed",
          target: "_blank"
        }, Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('methodNotAllowed405LinkText'))),
        type: "error",
        showIcon: true,
        style: {
          marginBottom: '10px'
        }
      }), _util__WEBPACK_IMPORTED_MODULE_5__["rclOpts"].showLicenseNotice === '1' && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Alert"], {
        message: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, "Product not activated, yet. ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: _util__WEBPACK_IMPORTED_MODULE_5__["rclOpts"].pluginsUrl
        }, "Activate now"), " \xB7 ", react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
          href: "#",
          onClick: this.handleDismissLicenseNotice
        }, "Dismiss notice"), "."),
        type: "info",
        cloxeText: "Dismiss for 20 days",
        style: {
          marginBottom: '10px'
        }
      }), methodMoved301Endpoint && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Alert"], {
        message: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("span", null, Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])('methodMoved301')),
        type: "error",
        showIcon: true,
        style: {
          marginBottom: '10px'
        }
      }), Object.keys(taxos).length > 1 && react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        style: {
          margin: '2px 0px 9px 0',
          textAlign: 'right'
        }
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_3__["TaxSwitcher"], _extends({
        disabled: !!this.state.toolbarActiveButton,
        onClick: this.handleTaxSwitch
      }, taxSwitcherAttr))));
    }
    /**
     * @returns {object}
     */

  }, {
    key: "resolveStateRefs",

    /**
     * Iterates all available values in an object and resolve it with the available
     * this::stateRefs.
     * 
     * @returns {object}
     */
    value: function resolveStateRefs(_obj, keys) {
      var obj = Object.assign({}, _obj);
      var value, newValue;

      for (var key in obj) {
        if (obj.hasOwnProperty(key) && (value = obj[key]) && this.stateRefs[keys].indexOf(key) > -1 && typeof value === 'string' && (newValue = this.resolveStateRef(value))) {
          obj[key] = newValue;
        }
      }

      return obj;
    }
    /**
     * Resolve single state ref key.
     * 
     * @returns {object}
     */

  }, {
    key: "resolveStateRef",
    value: function resolveStateRef(key) {
      if (typeof key !== 'string') {
        return;
      }

      if (key.indexOf('i18n.') === 0) {
        return Object(_util__WEBPACK_IMPORTED_MODULE_5__["i18n"])(key.substr(5));
      } else if (this.stateRefs[key]) {
        return this.stateRefs[key];
      }
    }
    /**
     * Fetch initial tree.
     */

  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      this.fetchTree();
    }
    /**
     * Initialize draggable and droppable.
     */

  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["draggable"])();
      Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["droppable"])(this);
    }
    /**
     * When the component updates the droppable zone is reinitialized.
     * Also the toolbar buttons gets disabled or enabled depending on selected node.
     */

  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      this._updateToolbarButtons();

      Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_6__["droppable"])(this);
    }
    /**
     * When the taxonomy gets changed the tree should be refetched.
     */

  }, {
    key: "componentWillUpdate",
    value: function componentWillUpdate(nextProps, _ref12) {
      var taxnow = _ref12.taxnow;

      // Fetch new tree if a new taxonomy is selected
      if (taxnow !== this.state.taxnow) {
        this.fetchTree(true, taxnow);
      }
    }
    /**
     * Get the selected node id.
     * 
     * @returns {string|int}
     */

  }, {
    key: "getSelectedId",
    value: function getSelectedId() {
      var selected = this.props.store.selected;
      return selected && selected.id;
    }
    /**
     * Get tree item by id.
     * 
     * @param {string|int} [id=Current]
     * @returns {object} Tree node
     */

  }, {
    key: "getTreeItemById",
    value: function getTreeItemById() {
      var id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.getSelectedId();
      var excludeStatic = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      return this.props.store.getTreeItemById(id, excludeStatic);
    }
    /**
     * Update a tree item by id.
     * 
     * @param {function} callback The callback with one argument (node draft) and should return the new node.
     * @param {string|int} [id=Current] The id which should be updated
     * @returns {Promise}
     */

  }, {
    key: "updateTreeItemById",
    value: function updateTreeItemById(callback) {
      var id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.getSelectedId();
      var node = this.props.store.getTreeItemById(id, false);
      node && node.setter(callback);
    }
    /**
     * Updates the create node. That's the node without id and the input field.
     * 
     * @param {function} callback The callback with one argument (node draft) and should return the new node.
     */

  }, {
    key: "updateCreateNode",
    value: function updateCreateNode(callback) {
      var createRoot = this.state.createRoot;
      createRoot && this.setState({
        createRoot: Object.assign(createRoot, callback)
      });
      this.updateTreeItemById(function (_ref13) {
        var $create = _ref13.$create;
        $create && callback($create);
      });
    }
    /**
     * Handles the creatable click and creates a new node depending on the selected one.
     * 
     * @method
     */

  }, {
    key: "_updateToolbarButtons",
    value: function _updateToolbarButtons() {
      var _this$state5 = this.state,
          toolbar_rename = _this$state5.toolbar_rename,
          toolbar_trash = _this$state5.toolbar_trash,
          selected = this.getTreeItemById(); // Enable / Disable toolbar buttons

      var disableIfStatic = !selected;
      toolbar_rename.disabled !== disableIfStatic && this.setState({
        toolbar_rename: Object.assign(toolbar_rename, {
          disabled: disableIfStatic
        }),
        toolbar_trash: Object.assign(toolbar_trash, {
          disabled: disableIfStatic
        })
      });
    }
    /**
     * Checks if the current window size is mobile.
     * 
     * @returns {boolean}
     * @method
     */

  }, {
    key: "fetchTree",

    /**
     * Fetch category tree.
     * 
     * @param {boolean} [remember=false] If true the taxonomy gets saved for the next page reload
     * @param {taxonomy} [taxonomy=Current] The taxonomy
     * @param {type} [type=Current] The post type
     * @param {string} [currentUrl=Current] The current url for determing the selected node
     */
    value: function fetchTree() {
      var _this3 = this;

      var remember = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      var taxonomy = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.state.taxnow;
      var type = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this.state.typenow;
      var currentUrl = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : window.location.href;
      this.props.store.setTree([]); // Reset tree for rerendering performance for massive tree's

      this.setState({
        isTreeBusy: true
      });
      this.props.store.fetchTree({
        remember: remember,
        type: type,
        taxonomy: taxonomy,
        currentUrl: currentUrl
      }, function (_ref14) {
        var selectedId = _ref14.selectedId;
        return _this3.setState({
          isTreeBusy: false
        });
      });
    }
  }]);

  return AppTree;
}(react__WEBPACK_IMPORTED_MODULE_1___default.a.Component)) || _class2) || _class2);


/***/ }),

/***/ "./public/src/admin.js":
/*!*****************************!*\
  !*** ./public/src/admin.js ***!
  \*****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./util */ "./public/src/util/index.js");
/* harmony import */ var _util_dragdrop__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./util/dragdrop */ "./public/src/util/dragdrop.js");
/* harmony import */ var _AppTree__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./AppTree */ "./public/src/AppTree.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./store */ "./public/src/store/index.js");
/* harmony import */ var _style_style_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./style/style.scss */ "./public/src/style/style.scss");
/* harmony import */ var _style_style_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_style_style_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_aiot_src_style_theme_wordpress_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-aiot/src/style/theme-wordpress.scss */ "./node_modules/react-aiot/src/style/theme-wordpress.scss");
/* harmony import */ var react_aiot_src_style_theme_wordpress_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_aiot_src_style_theme_wordpress_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var setimmediate__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! setimmediate */ "./node_modules/setimmediate/setImmediate.js");
/* harmony import */ var setimmediate__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(setimmediate__WEBPACK_IMPORTED_MODULE_10__);


function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/**
 * Startup file which initializes the AIO Tree.
 * 
 * @module admin
 */









 // Polyfill for yielding

/**
 * General event when script for RCL is ready to load.
 * 
 * @event module:util/hooks#general 
 */

_util__WEBPACK_IMPORTED_MODULE_4__["hooks"].call('general');
jquery__WEBPACK_IMPORTED_MODULE_3___default()(document).ready(
/*#__PURE__*/
_asyncToGenerator(
/*#__PURE__*/
_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
  var $container, containerId, typenow, taxnow, taxos, rclOptsAttr, allowsFastMode;
  return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          if (_util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"] && _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].screenSettings.isActive) {
            // Check if list table is available
            if (jquery__WEBPACK_IMPORTED_MODULE_3___default()('body').hasClass('wp-admin') && _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].isAvailable === "1" && jquery__WEBPACK_IMPORTED_MODULE_3___default()('.wp-list-table').size()) {
              containerId = 'rcl' + _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].blogId, typenow = _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].typenow, taxnow = _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].taxnow, taxos = _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].taxos, rclOptsAttr = {
                typenow: typenow,
                taxnow: taxnow,
                taxos: taxos
              }, allowsFastMode = _util__WEBPACK_IMPORTED_MODULE_4__["rclOpts"].screenSettings.isFastMode && window.history && window.history.pushState;
              /**
               * General event when DOM is ready and a list table is available.
               * 
               * @event module:admin#ready
               */

              _util__WEBPACK_IMPORTED_MODULE_4__["hooks"].call('ready'); // Create the container sidebar

              jquery__WEBPACK_IMPORTED_MODULE_3___default()('body').addClass('activate-aiot');
              $container = jquery__WEBPACK_IMPORTED_MODULE_3___default()('<div/>').prependTo('body.wp-admin #wpbody').addClass('rcl-container'); // Deactivate Simple Page Ordering

              !_util__WEBPACK_IMPORTED_MODULE_4__["isSortMode"] && jquery__WEBPACK_IMPORTED_MODULE_3___default()('.wp-list-table tbody.ui-sortable').sortable('destroy'); // Create the wrapper and React component

              react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.render(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_store__WEBPACK_IMPORTED_MODULE_7__["StoredAppTree"], _extends({
                id: containerId
              }, rclOptsAttr, {
                isFastMode: allowsFastMode
              })), $container.get(0));
              Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_5__["anyKeyHolding"])(); // Handler for pagination

              allowsFastMode && jquery__WEBPACK_IMPORTED_MODULE_3___default()(document).on('click', '.pagination-links a', function (e) {
                Object(_util__WEBPACK_IMPORTED_MODULE_4__["fastModeContent"])(jquery__WEBPACK_IMPORTED_MODULE_3___default()(this).attr('href')).then(function () {
                  Object(_util_dragdrop__WEBPACK_IMPORTED_MODULE_5__["draggable"])();
                });
                e.preventDefault();
                return false;
              });
            }
          }

        case 1:
        case "end":
          return _context.stop();
      }
    }
  }, _callee, this);
})));
jquery__WEBPACK_IMPORTED_MODULE_3___default()('link#dark_mode-css').size() && jquery__WEBPACK_IMPORTED_MODULE_3___default()('body').addClass('aiot-wp-dark-mode');

/***/ }),

/***/ "./public/src/components/index.js":
/*!****************************************!*\
  !*** ./public/src/components/index.js ***!
  \****************************************/
/*! exports provided: DashIcon, TaxSwitcher */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashIcon", function() { return DashIcon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaxSwitcher", function() { return TaxSwitcher; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_1__);
/** @module components */


/**
 * Create a WordPress dash icon.
 * 
 * @param {string} name The icon
 * @see https://developer.wordpress.org/resource/dashicons/ Available icons
 * @type React.Element
 */

var DashIcon = function DashIcon(_ref) {
  var name = _ref.name;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "dashicons dashicons-" + name
  });
};
/**
 * Create a tax switcher if more than one taxonomy is available for the post type.
 * 
 * @param {object} taxos Key value map of available taxonomies
 * @param {string} taxnow The current taxonomy
 * @param {boolean} disabled If true the taxonomy can not be switched
 * @param {function} onClick A taxonomy is selected
 * @type React.Element
 */

var TaxSwitcher = function TaxSwitcher(_ref2) {
  var taxos = _ref2.taxos,
      taxnow = _ref2.taxnow,
      disabled = _ref2.disabled,
      onClick = _ref2.onClick;
  var keys = Object.keys(taxos);

  if (keys.length <= 1) {
    return null;
  } // Create tax switcher overlay


  var overlayMenu = keys.map(function (key) {
    var label = taxos[key];
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
      key: key
    }, label);
  }),
      overlay = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_1__["Menu"], {
    selectedKeys: [taxnow],
    onClick: onClick
  }, overlayMenu);
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_1__["Dropdown"], {
    placement: "bottomRight",
    overlay: overlay,
    disabled: disabled
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    className: "ant-dropdown-link",
    href: "javascript:void(0)",
    style: {
      textDecoration: 'none'
    }
  }, taxos[taxnow], " ", react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_1__["Icon"], {
    type: "down"
  })));
};

/***/ }),

/***/ "./public/src/store/TreeNode.js":
/*!**************************************!*\
  !*** ./public/src/store/TreeNode.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "./public/src/util/index.js");
/* harmony import */ var mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mobx-state-tree */ "mobx-state-tree");
/* harmony import */ var mobx_state_tree__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_4__);


function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





/**
 * The store holding general data for categories.
 * 
 * @see React AIOT TreeNode documentation for properties and defaults
 */

var TreeNode = mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].model('RCLTreeNode', {
  id: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].identifier,
  hash: '',
  className: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  icon: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  iconActive: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  childNodes: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].array(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].late(function () {
    return TreeNode;
  }))),
  title: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen(),
  count: 0,
  attr: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  isTreeLinkDisabled: false,
  selected: false,
  $busy: false,
  $droppable: true,
  $visible: true,
  $rename: false,
  $create: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  properties: mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["types"].frozen()),
  isQueried: true
}).actions(function (self) {
  return {
    /**
     * Update this node attributes.
     * 
     * @param {function} callback The callback with one argument (node draft)
     * @param {boolean} [setHash] If true the hash node is changed so a rerender is forced
     */
    setter: function setter(callback) {
      var setHash = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      callback(self);
      setHash && (self.hash = Object(react_aiot__WEBPACK_IMPORTED_MODULE_4__["uuid"])());
    },

    /**
     * Rename folder.
     * 
     * @returns {object} Server response
     * @throws
     */
    setName: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(inputValue) {
      var result, _result, term_id, name, count, childNodes, rest;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              self.setter(function (node) {
                node.$busy = true;
              });
              _context.prev = 1;
              _context.next = 4;
              return Object(_util__WEBPACK_IMPORTED_MODULE_1__["ajax"])('terms/' + self.id, {
                method: 'PUT',
                data: {
                  name: inputValue,
                  taxonomy: self.properties.taxonomy
                }
              });

            case 4:
              _result = result = _context.sent;
              term_id = _result.term_id;
              name = _result.name;
              count = _result.count;
              childNodes = _result.childNodes;
              rest = _objectWithoutProperties(_result, ["term_id", "name", "count", "childNodes"]);
              self.setter(function (node) {
                node.title = inputValue;
                node.properties = jquery__WEBPACK_IMPORTED_MODULE_3___default.a.merge(node.properties, rest);
                node.$busy = false;
              });
              return _context.abrupt("return", result);

            case 14:
              _context.prev = 14;
              _context.t0 = _context["catch"](1);
              self.setter(function (node) {
                node.$busy = false;
              }, self.id);
              throw _context.t0;

            case 18:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this, [[1, 14]]);
    })),

    /**
     * Permanently delete category.
     * 
     * @returns {string|int} The parent id
     * @throws
     */
    trash: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_2__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              self.setter(function (node) {
                node.$busy = true;
              });
              _context2.prev = 1;
              _context2.next = 4;
              return Object(_util__WEBPACK_IMPORTED_MODULE_1__["ajax"])('terms/' + self.id, {
                method: 'DELETE',
                data: {
                  taxonomy: self.properties.taxonomy
                }
              });

            case 4:
              self.setter(function (node) {
                node.$visible = false;
              });
              _context2.next = 10;
              break;

            case 7:
              _context2.prev = 7;
              _context2.t0 = _context2["catch"](1);
              throw _context2.t0;

            case 10:
              _context2.prev = 10;
              self.setter(function (node) {
                node.$busy = false;
              });
              return _context2.finish(10);

            case 13:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, this, [[1, 7, 10, 13]]);
    }))
  };
});
/* harmony default export */ __webpack_exports__["default"] = (TreeNode);

/***/ }),

/***/ "./public/src/store/index.js":
/*!***********************************!*\
  !*** ./public/src/store/index.js ***!
  \***********************************/
/*! exports provided: default, StoredAppTree, injectAndObserve, TreeNode */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoredAppTree", function() { return StoredAppTree; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "injectAndObserve", function() { return injectAndObserve; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mobx-react */ "./node_modules/mobx-react/index.module.js");
/* harmony import */ var _AppTree__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../AppTree */ "./public/src/AppTree.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util */ "./public/src/util/index.js");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! mobx-state-tree */ "mobx-state-tree");
/* harmony import */ var mobx_state_tree__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _TreeNode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./TreeNode */ "./public/src/store/TreeNode.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TreeNode", function() { return _TreeNode__WEBPACK_IMPORTED_MODULE_6__["default"]; });



function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








/**
 * The main store for the RCL application. It holds a static tree and
 * the fetched tree from the server.
 */

var Store = mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].model('RCLStore', {
  staticTree: mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].array(_TreeNode__WEBPACK_IMPORTED_MODULE_6__["default"]),
  tree: mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].array(_TreeNode__WEBPACK_IMPORTED_MODULE_6__["default"]), []),
  refs: mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].map(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].reference(_TreeNode__WEBPACK_IMPORTED_MODULE_6__["default"])), {}),
  selectedId: mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].union(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].string, mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].number), 0),
  // Do not fill manually, it is filled in afterCreated through onPatch
  methodNotAllowed405Endpoint: mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].optional(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["types"].string, ''),
  methodMoved301Endpoint: false
}).views(function (self) {
  return {
    /**
     * Get tree item by id.
     * 
     * @param {string|int} id
     * @param {boolean} [exlucdeStatic=true]
     * @returns {TreeNode} Tree node
     */
    getTreeItemById: function getTreeItemById(id) {
      var excludeStatic = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      var useId = parseInt(id, 10),
          result = Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["resolveIdentifier"])(_TreeNode__WEBPACK_IMPORTED_MODULE_6__["default"], self, isNaN(useId) ? id : useId);

      if (excludeStatic && self.staticTree.indexOf(result) > -1) {
        return undefined;
      }

      return result;
    },

    get selected() {
      return self.getTreeItemById(self.selectedId, false);
    }

  };
}).actions(function (self) {
  return {
    /**
     * The model is created so watch for specific properties. For example set
     * the selected property.
     */
    afterCreate: function afterCreate() {
      Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["onPatch"])(self, function (_ref) {
        var op = _ref.op,
            path = _ref.path,
            value = _ref.value;

        // A new selected item is setted
        if ((path.startsWith('/tree/') || path.startsWith('/staticTree/')) && path.endsWith('/selected') && value === true) {
          var currentSelected = self.selected;
          currentSelected && currentSelected.setter(function (node) {
            node.selected = false;
          });

          self._setSelectedIdFromPath(path.slice(0, path.length - 9));
        }
      });
    },
    _setSelectedIdFromPath: function _setSelectedIdFromPath(path) {
      self.selectedId = Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["resolvePath"])(self, path).id;
    },

    /**
     * Update this node attributes.
     * 
     * @param {function} callback The callback with one argument (node draft)
     * @memberof module:store~Store
     * @instance
     */
    setter: function setter(callback) {
      callback(self);
    },

    /**
     * Set the tree.
     */
    setTree: function setTree(tree) {
      var isStatic = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

      if (isStatic) {
        self.staticTree.replace(tree);
      } else {
        self.tree.replace(tree);
      }
    },

    /**
     * Handle sort mechanism.
     * 
     * @returns {boolean}
     * @throws
     */
    handleSort: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref2, type, taxonomy) {
      var id, buildTree, oldIndex, newIndex, parentFromId, parentToId, nextId, _ref2$request, request, tree, treeItem;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              id = _ref2.id, buildTree = _ref2.buildTree, oldIndex = _ref2.oldIndex, newIndex = _ref2.newIndex, parentFromId = _ref2.parentFromId, parentToId = _ref2.parentToId, nextId = _ref2.nextId, _ref2$request = _ref2.request, request = _ref2$request === void 0 ? true : _ref2$request;
              tree = self.tree; // Find parent trees with children

              if (parentFromId === 0) {
                treeItem = tree[oldIndex].toJSON();
                tree.splice(oldIndex, 1);
              } else {
                self.getTreeItemById(parentFromId).setter(function (node) {
                  treeItem = node.childNodes[oldIndex].toJSON();
                  node.childNodes.splice(oldIndex, 1);
                }, true);
              } // Find destination tree


              if (parentToId === 0) {
                tree.splice(newIndex, 0, treeItem);
              } else {
                self.getTreeItemById(parentToId).setter(function (node) {
                  node.childNodes.splice(newIndex, 0, treeItem);
                }, true);
              }

              if (request) {
                _context.next = 6;
                break;
              }

              return _context.abrupt("return", true);

            case 6:
              _context.prev = 6;
              _context.next = 9;
              return Object(_util__WEBPACK_IMPORTED_MODULE_3__["ajax"])('hierarchy/' + id, {
                method: 'PUT',
                data: {
                  parent: parentToId,
                  nextId: nextId,
                  type: type,
                  taxonomy: taxonomy
                }
              });

            case 9:
              return _context.abrupt("return", true);

            case 12:
              _context.prev = 12;
              _context.t0 = _context["catch"](6);
              _context.next = 16;
              return store.handleSort({
                id: id,
                oldIndex: newIndex,
                newIndex: oldIndex,
                parentFromId: parentToId,
                parentToId: parentFromId,
                request: false
              });

            case 16:
              throw _context.t0;

            case 17:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, this, [[6, 12]]);
    })),

    /**
     * @deprecated The hierarchy is now saved with relocate-method
     */
    persistSort: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(_ref3) {
      var type, taxonomy, hierarchy;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              type = _ref3.type, taxonomy = _ref3.taxonomy;
              hierarchy = Object(react_aiot__WEBPACK_IMPORTED_MODULE_4__["buildOrderedParentPairs"])(self.tree);
              _context2.next = 4;
              return Object(_util__WEBPACK_IMPORTED_MODULE_3__["ajax"])('hierarchy', {
                method: 'PUT',
                data: {
                  type: type,
                  taxonomy: taxonomy,
                  hierarchy: hierarchy
                }
              });

            case 4:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, this);
    })),

    /**
     * Create a new tree node.
     */
    persist: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3(data) {
      var _ref4, term_id, count, name, rest, newObj, parent;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return Object(_util__WEBPACK_IMPORTED_MODULE_3__["ajax"])('terms', {
                method: 'POST',
                data: data
              });

            case 2:
              _ref4 = _context3.sent;
              term_id = _ref4.term_id;
              count = _ref4.count;
              name = _ref4.name;
              rest = _objectWithoutProperties(_ref4, ["term_id", "count", "name"]);
              newObj = {
                id: term_id,
                title: name,
                icon: _util__WEBPACK_IMPORTED_MODULE_3__["ICON_OBJ_FOLDER_CLOSED"],
                iconActive: _util__WEBPACK_IMPORTED_MODULE_3__["ICON_OBJ_FOLDER_OPEN"],
                count: count,
                childNodes: [],
                properties: rest
              };
              // Add it to the tree
              parent = data.parent;

              if (parent === 0) {
                self.tree.push(newObj);
              } else {
                self.getTreeItemById(parent).setter(function (node) {
                  node.childNodes.push(newObj);
                }, true);
              }

              return _context3.abrupt("return", self.getTreeItemById(term_id));

            case 11:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, this);
    })),

    /**
     * Fetch the folder tree.
     * 
     * @returns {object[]} Tree
     */
    fetchTree: Object(mobx_state_tree__WEBPACK_IMPORTED_MODULE_5__["flow"])(
    /*#__PURE__*/
    _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee4(_ref5, callback) {
      var remember, type, taxonomy, currentUrl, _ref6, tree, selectedId, result;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              remember = _ref5.remember, type = _ref5.type, taxonomy = _ref5.taxonomy, currentUrl = _ref5.currentUrl;
              _context4.next = 3;
              return Object(_util__WEBPACK_IMPORTED_MODULE_3__["fetchTree"])({
                data: {
                  remember: remember,
                  type: type,
                  taxonomy: taxonomy,
                  currentUrl: currentUrl
                }
              });

            case 3:
              _ref6 = _context4.sent;
              tree = _ref6.tree;
              selectedId = _ref6.selectedId;
              result = {
                tree: tree,
                selectedId: selectedId
              };
              self.setTree(tree);
              self.getTreeItemById(selectedId, false).setter(function (node) {
                node.selected = true;
              });
              callback && callback(result);
              return _context4.abrupt("return", result);

            case 11:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4, this);
    }))
  };
});
var store = Store.create({
  staticTree: [{
    id: 'ALL',
    title: Object(_util__WEBPACK_IMPORTED_MODULE_3__["i18n"])('allPosts'),
    icon: React.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_4__["Icon"], {
      type: "copy"
    }),
    count: _util__WEBPACK_IMPORTED_MODULE_3__["rclOpts"].allPostCnt
  }]
});
/**
 * A single instance of store.
 */

/* harmony default export */ __webpack_exports__["default"] = (store);
window.rcl = {
  store: store
};
/**
 * An AppTree implementation with store provided. This means you have no longer
 * implement the Provider of mobx here.
 */

var StoredAppTree = function StoredAppTree(_ref7) {
  var children = _ref7.children,
      rest = _objectWithoutProperties(_ref7, ["children"]);

  return React.createElement(mobx_react__WEBPACK_IMPORTED_MODULE_1__["Provider"], {
    store: store
  }, React.createElement(_AppTree__WEBPACK_IMPORTED_MODULE_2__["default"], rest, children));
};
/**
 * Import general store to ReactJS component.
 */

function injectAndObserve(fn) {
  var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'store';
  return Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["inject"])(store)(Object(mobx_react__WEBPACK_IMPORTED_MODULE_1__["observer"])(fn));
}


/***/ }),

/***/ "./public/src/style/style.scss":
/*!*************************************!*\
  !*** ./public/src/style/style.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./public/src/util/addUrlParam.js":
/*!****************************************!*\
  !*** ./public/src/util/addUrlParam.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return addUrlParam; });
/**
 * Add a URL parameter (or changing it if it already exists)
 * 
 * @param {string} url The url
 * @param {string} parameterName The parameter name
 * @param {string} parameterValue The parameter value
 * @param {boolean} [atStart] Add param before others
 * @returns {string} URL
 * @see http://stackoverflow.com/questions/486896/adding-a-parameter-to-the-url-with-javascript
 * @see http://stackoverflow.com/questions/6953944/how-to-add-parameters-to-a-url-that-already-contains-other-parameters-and-maybe?noredirect=1&lq=1
 * @module util/addUrlParam
 */
function addUrlParam(url, parameterName, parameterValue, atStart) {
  var replaceDuplicates = true,
      urlhash,
      sourceUrl;

  if (url.indexOf('#') > 0) {
    var cl = url.indexOf('#');
    urlhash = url.substring(url.indexOf('#'), url.length);
  } else {
    urlhash = '';
    cl = url.length;
  }

  sourceUrl = url.substring(0, cl);
  var urlParts = sourceUrl.split("?");
  var newQueryString = "";

  if (urlParts.length > 1) {
    var parameters = urlParts[1].split("&");

    for (var i = 0; i < parameters.length; i++) {
      var parameterParts = parameters[i].split("=");

      if (!(replaceDuplicates && parameterParts[0] == parameterName)) {
        if (newQueryString == "") newQueryString = "?";else newQueryString += "&";
        newQueryString += parameterParts[0] + "=" + (parameterParts[1] ? parameterParts[1] : '');
      }
    }
  }

  if (newQueryString == "") newQueryString = "?";

  if (atStart) {
    newQueryString = '?' + parameterName + "=" + parameterValue + (newQueryString.length > 1 ? '&' + newQueryString.substring(1) : '');
  } else {
    if (newQueryString !== "" && newQueryString != '?') newQueryString += "&";
    newQueryString += parameterName + "=" + (parameterValue ? parameterValue : '');
  }

  return urlParts[0] + newQueryString + urlhash;
}

/***/ }),

/***/ "./public/src/util/dragdrop.js":
/*!*************************************!*\
  !*** ./public/src/util/dragdrop.js ***!
  \*************************************/
/*! exports provided: anyKeyHolding, droppable, draggable */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "anyKeyHolding", function() { return anyKeyHolding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "droppable", function() { return droppable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "draggable", function() { return draggable; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! . */ "./public/src/util/index.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_5__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/** @module util/dragdrop */






/**
 * On CTRL holding add class 'aiot-helper-method-append' to document body.
 */

function anyKeyHolding() {
  jquery__WEBPACK_IMPORTED_MODULE_5___default()(document).on('keydown', function (e) {
    return jquery__WEBPACK_IMPORTED_MODULE_5___default()('body').addClass('aiot-helper-method-append');
  });
  jquery__WEBPACK_IMPORTED_MODULE_5___default()(document).on('keyup', function (e) {
    return jquery__WEBPACK_IMPORTED_MODULE_5___default()('body').removeClass('aiot-helper-method-append');
  });
}
/**
 * Enables / Reinitializes the droppable nodes. If a draggable item is dropped
 * here the given posts are moved to the category. You have to provide a ReactJS
 * element to reload the tree.
 * 
 * @param {React.Element} element The element
 */

function droppable(element) {
  var dom = jquery__WEBPACK_IMPORTED_MODULE_5___default()('#' + element.props.id + ' li.aiot-sortable .aiot-node.aiot-droppable');
  dom.droppable({
    activeClass: 'aiot-state-default',
    hoverClass: 'aiot-state-hover',
    tolerance: 'pointer',
    drop: function () {
      var _drop = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(event, ui) {
        var ids, to, removeElements, isCopy, taxonomy, elementsIterate, iterateChecked, isOne, i18nProps, i18nGet, hide;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                ids = [], to = jquery__WEBPACK_IMPORTED_MODULE_5___default()(event.target).attr('data-id'), removeElements = [], isCopy = jquery__WEBPACK_IMPORTED_MODULE_5___default()('body').hasClass('aiot-helper-method-append'), taxonomy = jquery__WEBPACK_IMPORTED_MODULE_5___default()(event.target).parents('.aiot-tree').attr('data-tax'), elementsIterate = function elementsIterate(cb) {
                  for (var i = 0; i < removeElements.length; i++) {
                    cb(removeElements[i]);
                  }
                }, iterateChecked = function iterateChecked(ui, cb) {
                  // List-mode
                  var trs = jquery__WEBPACK_IMPORTED_MODULE_5___default()('input[name="post[]"]:checked'); // Multiselect

                  if (trs.size() > 0) {
                    trs.each(function () {
                      cb(jquery__WEBPACK_IMPORTED_MODULE_5___default()(this).parents('tr'));
                    });
                  } else {
                    // One selected
                    cb(ui);
                  }
                }; // Parse the item ids and remove them

                iterateChecked(ui.draggable, function (tr) {
                  ids.push(parseInt(tr.find('input[name="post[]"]').attr('value'), 10));
                  removeElements.push(tr);
                }); // The function to progress the move

                elementsIterate(function (obj) {
                  return jquery__WEBPACK_IMPORTED_MODULE_5___default()(obj).fadeTo(250, 0.3);
                }); // Get i18n key

                isOne = ids.length === 1, i18nProps = {
                  count: ids.length,
                  category: jquery__WEBPACK_IMPORTED_MODULE_5___default()(event.target).find('.aiot-node-name').html()
                }, i18nGet = function i18nGet(key) {
                  return Object(___WEBPACK_IMPORTED_MODULE_4__["i18n"])((isCopy ? 'append' : 'move') + key + (isOne ? 'One' : ''), i18nProps);
                };
                hide = react_aiot__WEBPACK_IMPORTED_MODULE_3__["message"].loading(i18nGet('LoadingText'));
                _context.prev = 5;
                _context.next = 8;
                return Object(___WEBPACK_IMPORTED_MODULE_4__["ajax"])('posts/bulk/move', {
                  method: 'PUT',
                  data: {
                    ids: ids,
                    to: to,
                    isCopy: isCopy,
                    taxonomy: taxonomy
                  }
                });

              case 8:
                hide();
                react_aiot__WEBPACK_IMPORTED_MODULE_3__["message"].success(i18nGet('Success'));
                element.fetchTree(); // Update WP Table

                if (isCopy) {
                  // Reload the WP List table
                  jquery__WEBPACK_IMPORTED_MODULE_5___default.a.get(window.location.href, {}, function (response) {
                    var doc = jquery__WEBPACK_IMPORTED_MODULE_5___default()(response),
                        tableRows = doc.find('.wp-list-table tbody tr');

                    if (tableRows.size() > 0) {
                      var postId, tableRow;
                      elementsIterate(function (obj) {
                        postId = jquery__WEBPACK_IMPORTED_MODULE_5___default()(obj).attr('id');
                        tableRow = doc.find('#' + postId);
                        jquery__WEBPACK_IMPORTED_MODULE_5___default()(obj).replaceWith(tableRow);
                      });
                    }
                  });
                } else {
                  // Remove items
                  elementsIterate(function (obj) {
                    return jquery__WEBPACK_IMPORTED_MODULE_5___default()(obj).remove();
                  });
                } // Add no media


                if (!jquery__WEBPACK_IMPORTED_MODULE_5___default()(".wp-list-table tbody tr").size()) {
                  jquery__WEBPACK_IMPORTED_MODULE_5___default()(".wp-list-table tbody").html('<tr class="no-items"><td class="colspanchange" colspan="6">' + ___WEBPACK_IMPORTED_MODULE_4__["rclOpts"].lang.noEntries + '</td></tr></tbody>');
                }

                _context.next = 18;
                break;

              case 15:
                _context.prev = 15;
                _context.t0 = _context["catch"](5);
                console.log(_context.t0); // Usually there should be no error... Silence is golden.

              case 18:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[5, 15]]);
      }));

      return function drop(_x, _x2) {
        return _drop.apply(this, arguments);
      };
    }()
  });
}
/**
 * Make the list table draggable if sort mode is not active.
 */

function draggable() {
  // No dragging in sort mode
  if (___WEBPACK_IMPORTED_MODULE_4__["isSortMode"]) {
    return;
  }

  jquery__WEBPACK_IMPORTED_MODULE_5___default()('#wpbody-content .wp-list-table tbody tr:not(.no-items)').draggable({
    revert: 'invalid',
    revertDuration: 0,
    appendTo: 'body',
    cursorAt: {
      top: 0,
      left: 0
    },
    distance: 10,
    refreshPositions: true,
    helper: function helper() {
      var helperId = Object(react_aiot__WEBPACK_IMPORTED_MODULE_3__["uuid"])(),
          helper = jquery__WEBPACK_IMPORTED_MODULE_5___default()('<div id="' + helperId + '" class="aiot-helper"></div>'),
          count = jquery__WEBPACK_IMPORTED_MODULE_5___default()('input[name="post[]"]:checked').size();
      helper.appendTo(jquery__WEBPACK_IMPORTED_MODULE_5___default()('body'));
      react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.render(react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "aiot-helper-method-move"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
        type: "swap"
      }), " ", Object(___WEBPACK_IMPORTED_MODULE_4__["i18n"])(count > 1 ? 'move' : 'moveOne', {
        count: count
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, Object(___WEBPACK_IMPORTED_MODULE_4__["i18n"])('moveTip'))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
        className: "aiot-helper-method-append"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_3__["Icon"], {
        type: "copy"
      }), " ", Object(___WEBPACK_IMPORTED_MODULE_4__["i18n"])(count > 1 ? 'append' : 'appendOne', {
        count: count
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", null, Object(___WEBPACK_IMPORTED_MODULE_4__["i18n"])('appendTip')))), document.getElementById(helperId));
      return helper;
    },
    start: function start(event) {
      jquery__WEBPACK_IMPORTED_MODULE_5___default()('body').addClass('aiot-currently-dragging'); // FIX https://bugs.jqueryui.com/ticket/4261

      jquery__WEBPACK_IMPORTED_MODULE_5___default()(document.activeElement).blur();
    },
    stop: function stop() {
      jquery__WEBPACK_IMPORTED_MODULE_5___default()('body').removeClass("aiot-currently-dragging");
    }
  });
}

/***/ }),

/***/ "./public/src/util/fastModeContent.js":
/*!********************************************!*\
  !*** ./public/src/util/fastModeContent.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_1__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

/* global inlineEditPost*/

/**
 * Loads the given href and replaces the current list table.
 * 
 * @module util/fastModeContent
 * @param {string} href The link to load
 */

/* harmony default export */ __webpack_exports__["default"] = (function (_x) {
  return _ref.apply(this, arguments);
});

function _ref() {
  _ref = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(href) {
    var tableFilter;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            tableFilter = jquery__WEBPACK_IMPORTED_MODULE_1___default()("form#posts-filter");
            tableFilter.stop().fadeTo(250, 0.5);
            window.history.pushState({}, '', href); // Get the new table item rows

            _context.next = 5;
            return jquery__WEBPACK_IMPORTED_MODULE_1___default.a.get(href, {}, function (response) {
              var doc = jquery__WEBPACK_IMPORTED_MODULE_1___default()(response),
                  newTable = doc.find('form#posts-filter');
              tableFilter.replaceWith(newTable);
              /**
               * ported from inline-edit-post.js
               */
              //inlineEditPost.init();

              var t = inlineEditPost,
                  qeRow = jquery__WEBPACK_IMPORTED_MODULE_1___default()('#inline-edit'),
                  bulkRow = jquery__WEBPACK_IMPORTED_MODULE_1___default()('#bulk-edit');
              t.type = jquery__WEBPACK_IMPORTED_MODULE_1___default()('table.widefat').hasClass('pages') ? 'page' : 'post';
              t.what = '#post-'; // prepare the edit rows

              qeRow.keyup(function (e) {
                if (e.which === 27) {
                  return inlineEditPost.revert();
                }
              });
              bulkRow.keyup(function (e) {
                if (e.which === 27) {
                  return inlineEditPost.revert();
                }
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('.cancel', qeRow).click(function () {
                return inlineEditPost.revert();
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('.save', qeRow).click(function () {
                return inlineEditPost.save(this);
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('td', qeRow).keydown(function (e) {
                if (e.which === 13 && !jquery__WEBPACK_IMPORTED_MODULE_1___default()(e.target).hasClass('cancel')) {
                  return inlineEditPost.save(this);
                }
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('.cancel', bulkRow).click(function () {
                return inlineEditPost.revert();
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('#inline-edit .inline-edit-private input[value="private"]').click(function () {
                var pw = jquery__WEBPACK_IMPORTED_MODULE_1___default()('input.inline-edit-password-input');

                if (jquery__WEBPACK_IMPORTED_MODULE_1___default()(this).prop('checked')) {
                  pw.val('').prop('disabled', true);
                } else {
                  pw.prop('disabled', false);
                }
              }); // add events

              jquery__WEBPACK_IMPORTED_MODULE_1___default()('#the-list').on('click', 'a.editinline', function (e) {
                e.preventDefault();
                inlineEditPost.edit(this);
              });
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('select[name="_status"] option[value="future"]', bulkRow).remove();
              jquery__WEBPACK_IMPORTED_MODULE_1___default()('#doaction, #doaction2').click(function (e) {
                var n;
                t.whichBulkButtonId = jquery__WEBPACK_IMPORTED_MODULE_1___default()(this).attr('id');
                n = t.whichBulkButtonId.substr(2);

                if ('edit' === jquery__WEBPACK_IMPORTED_MODULE_1___default()('select[name="' + n + '"]').val()) {
                  e.preventDefault();
                  t.setBulk();
                } else if (jquery__WEBPACK_IMPORTED_MODULE_1___default()('form#posts-filter tr.inline-editor').length > 0) {
                  t.revert();
                }
              });
            });

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, this);
  }));
  return _ref.apply(this, arguments);
}

/***/ }),

/***/ "./public/src/util/hooks.js":
/*!**********************************!*\
  !*** ./public/src/util/hooks.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Hook system to modify simple things.
 * 
 * @module util/hooks
 * @see Events for hook events
 * @example <caption>Accessing the hook system</caption>
 * window.rcl.hooks.register("yourAction", function() {
 *  // Do something
 * });
 */

window.rcl = window.rcl || {};
var registry = [],
    hooks = window.rcl.hooks = {
  /**
   * Registers a callback to a given event name.
   * 
   * @param {string} names The event name, you can also pass multiple names when splitted with " "
   * @param {function} callback The callback function with the arguments
   * @returns {module:util/hooks}
   * @function register
   */
  register: function register(names, callback) {
    names.split(' ').forEach(function (name) {
      registry[name] = registry[name] || [];
      registry[name].push(callback);
    });
    return hooks;
  },

  /**
   * Call an event.
   * 
   * @param {string} name The event name
   * @param {mixed[]} args Pass arguments to the callbacks
   * @param {object} context Pass context to the callbacks
   * @returns {module:util/hooks}
   * @function call
   */
  call: function call(name, args, context) {
    if (registry[name]) {
      if (args) {
        if (Object.prototype.toString.call(args) === '[object Array]') {
          args.push(jquery__WEBPACK_IMPORTED_MODULE_0___default.a);
        } else {
          args = [args, jquery__WEBPACK_IMPORTED_MODULE_0___default.a];
        }
      } else {
        args = [jquery__WEBPACK_IMPORTED_MODULE_0___default.a];
      } // When explicit false then break the for


      registry[name].forEach(function (callback) {
        return callback.apply(context, [jquery__WEBPACK_IMPORTED_MODULE_0___default.a]) !== false;
      });
    }

    return hooks;
  },

  /**
   * Checks if a event name is registered.
   * 
   * @param {string} name The event name
   * @returns {boolean}
   * @function exists
   */
  exists: function exists(name) {
    return !!registry[name];
  }
};
/* harmony default export */ __webpack_exports__["default"] = (hooks);

/***/ }),

/***/ "./public/src/util/index.js":
/*!**********************************!*\
  !*** ./public/src/util/index.js ***!
  \**********************************/
/*! exports provided: untrailingslashit, trailingslashit, i18n, urlParam, ajax, ICON_OBJ_FOLDER_OPEN, ICON_OBJ_FOLDER_CLOSED, $byOrder, isSortModeAvailable, isSortMode, applyNodeDefaults, fetchTree, addUrlParam, fastModeContent, hooks, uri, rclOpts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "untrailingslashit", function() { return untrailingslashit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trailingslashit", function() { return trailingslashit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i18n", function() { return i18n; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "urlParam", function() { return urlParam; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ajax", function() { return ajax; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ICON_OBJ_FOLDER_OPEN", function() { return ICON_OBJ_FOLDER_OPEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ICON_OBJ_FOLDER_CLOSED", function() { return ICON_OBJ_FOLDER_CLOSED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "$byOrder", function() { return $byOrder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSortModeAvailable", function() { return isSortModeAvailable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSortMode", function() { return isSortMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyNodeDefaults", function() { return applyNodeDefaults; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTree", function() { return fetchTree; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery */ "jquery");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _addUrlParam__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./addUrlParam */ "./public/src/util/addUrlParam.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "addUrlParam", function() { return _addUrlParam__WEBPACK_IMPORTED_MODULE_2__["default"]; });

/* harmony import */ var _fastModeContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fastModeContent */ "./public/src/util/fastModeContent.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fastModeContent", function() { return _fastModeContent__WEBPACK_IMPORTED_MODULE_3__["default"]; });

/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./hooks */ "./public/src/util/hooks.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "hooks", function() { return _hooks__WEBPACK_IMPORTED_MODULE_4__["default"]; });

/* harmony import */ var rclopts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rclopts */ "rclopts");
/* harmony import */ var rclopts__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rclopts__WEBPACK_IMPORTED_MODULE_5__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "rclOpts", function() { return rclopts__WEBPACK_IMPORTED_MODULE_5___default.a; });
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-aiot */ "react-aiot");
/* harmony import */ var react_aiot__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_aiot__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! i18n-react */ "i18n-react");
/* harmony import */ var i18n_react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(i18n_react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var lil_uri__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lil-uri */ "./node_modules/lil-uri/uri.js");
/* harmony import */ var lil_uri__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lil_uri__WEBPACK_IMPORTED_MODULE_8__);
/* harmony reexport (default from non-harmony) */ __webpack_require__.d(__webpack_exports__, "uri", function() { return lil_uri__WEBPACK_IMPORTED_MODULE_8___default.a; });


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/** @module util */









var untrailingslashit = function untrailingslashit(str) {
  return str.endsWith('/') || str.endsWith('\\') ? untrailingslashit(str.slice(0, -1)) : str;
};
var trailingslashit = function trailingslashit(str) {
  return untrailingslashit(str) + '/';
};
var WP_REST_API_USE_GLOBAL_METHOD = true;
/**
 * Creates a React component (span) with the translated markdown.
 * 
 * @param {string} key The key in rclOpts.lang
 * @param {object} [params] The parameters
 * @param {object|string('maxWidth')} [spanWrapperProps] Wraps an additinal span wrapper with custom attributes
 * @see https://github.com/alexdrel/i18n-react
 * @returns {React.Element} Or null if key not found
 */

function i18n(key, params, spanWrapperProps) {
  if (rclopts__WEBPACK_IMPORTED_MODULE_5___default.a && rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.lang[key]) {
    var span = React.createElement(i18n_react__WEBPACK_IMPORTED_MODULE_7___default.a.span, _extends({
      text: rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.lang[key]
    }, params)); // Predefined span wrapper props

    if (typeof spanWrapperProps === 'string') {
      switch (spanWrapperProps) {
        case 'maxWidth':
          spanWrapperProps = {
            style: {
              display: 'inline-block',
              maxWidth: 200
            }
          };
          break;

        default:
          break;
      }
    }

    return spanWrapperProps ? React.createElement("span", spanWrapperProps, span) : span;
  }

  return null;
}
/**
 * Get URL parameter of current url.
 * 
 * @param {string} name The parameter name
 * @param {string} [url=window.location.href]
 * @returns {string|null}
 */

function urlParam(name) {
  var url = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : window.location.href;
  var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(url);
  return results && results[1] || null;
}
/**
 * Execute a jQuery request with X-WP-Nonce header.
 * 
 * @param {string} url The url appended to ".../wp-json/realcategorylibrary/v1/"
 * @param {object} [settings] The options for jQuery.ajax
 * @param {string} [url='realcategorylibrary/v1'] The API namespace
 * @returns Result of jQuery.ajax
 */

function ajax(url) {
  var settings = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var urlNamespace = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'realcategorylibrary/v1';

  /* global rcl */
  var apiUrl = lil_uri__WEBPACK_IMPORTED_MODULE_8___default()(rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.restRoot);
  var windowProtocol = lil_uri__WEBPACK_IMPORTED_MODULE_8___default()(window.location.href).protocol(),
      query = apiUrl.query() || {},
      path = query.rest_route || apiUrl.path(),
      // Determine path from permalink settings
  usePath = trailingslashit(path) + trailingslashit(urlNamespace) + url;
  windowProtocol === 'https' && apiUrl.protocol('https'); // Set https if site url is SSL
  // Set path depending on permalink settings

  if (query.rest_route) {
    query.rest_route = usePath;
  } else {
    apiUrl.path(usePath); // Set path
  } // Use global parameter (see https://developer.wordpress.org/rest-api/using-the-rest-api/global-parameters/)


  if (WP_REST_API_USE_GLOBAL_METHOD && settings.method && settings.method.toUpperCase() !== 'GET') {
    query._method = settings.method;
    settings.method = 'POST';
  }

  var promise = jquery__WEBPACK_IMPORTED_MODULE_1___default.a.ajax(jquery__WEBPACK_IMPORTED_MODULE_1___default.a.extend(true, settings, {
    url: apiUrl.query(jquery__WEBPACK_IMPORTED_MODULE_1___default.a.extend(true, {}, rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.restQuery, query)).build(),
    headers: {
      'X-WP-Nonce': rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.restNonce
    }
  })),
      _url = url;
  urlNamespace.startsWith('realcategorylibrary') && promise.fail(function (_ref) {
    var status = _ref.status;
    status === 405 && rcl && rcl.store && rcl.store.setter(function (self) {
      self.methodNotAllowed405Endpoint = (settings && settings.method ? settings.method : 'GET') + ' ' + _url;
    });
  });
  return promise;
}
/**
 * Icon showing a opened folder.
 * 
 * @type React.Element
 */

var ICON_OBJ_FOLDER_OPEN = React.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
  type: "folder-open"
});
/**
 * Icon showing a closed folder.
 * 
 * @type React.Element
 */

var ICON_OBJ_FOLDER_CLOSED = React.createElement(react_aiot__WEBPACK_IMPORTED_MODULE_6__["Icon"], {
  type: "folder"
});
/**
 * A jQuery object selecting the byorder link above the wp list table.
 * 
 * @type jQuery
 */

var $byOrder = jquery__WEBPACK_IMPORTED_MODULE_1___default()('ul.subsubsub li.byorder');
/**
 * If true there is a sort mode available.
 * 
 * @type boolean
 */

var isSortModeAvailable = !!$byOrder.size();
/**
 * If true the sort mode is currently active (selected).
 * 
 * @type boolean
 */

var isSortMode = isSortModeAvailable && rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.editOrderBy.toLowerCase() === 'menu_order title' && rclopts__WEBPACK_IMPORTED_MODULE_5___default.a.editOrder.toLowerCase() === 'asc';
/**
 * Handle tree node defaults for loaded folder items and new items.
 * 
 * @param {object[]} folders The folders
 * @returns object[]
 */

function applyNodeDefaults(arr) {
  return arr.map(function (_ref2) {
    var term_id = _ref2.term_id,
        name = _ref2.name,
        count = _ref2.count,
        childNodes = _ref2.childNodes,
        rest = _objectWithoutProperties(_ref2, ["term_id", "name", "count", "childNodes"]);

    return function (node) {
      _hooks__WEBPACK_IMPORTED_MODULE_4__["default"].call('tree/node', [node]);
      return node;
    }(jquery__WEBPACK_IMPORTED_MODULE_1___default.a.extend({}, react_aiot__WEBPACK_IMPORTED_MODULE_6__["TreeNode"].defaultProps, {
      // Default node
      id: term_id,
      title: name,
      icon: ICON_OBJ_FOLDER_CLOSED,
      iconActive: ICON_OBJ_FOLDER_OPEN,
      count: count,
      childNodes: childNodes ? applyNodeDefaults(childNodes) : [],
      properties: rest,
      className: {},
      $visible: true
    }));
  });
}
/**
 * Execute the REST query to fetch the category tree.
 * 
 * @param {object} [settings] Additional options for jQuery.ajax
 * @returns {object} The original AJAX result and the tree result prepared for AIO
 */

function fetchTree(_x) {
  return _fetchTree.apply(this, arguments);
}

function _fetchTree() {
  _fetchTree = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(settings) {
    var _ref3, tree, selectedId;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return ajax('tree', settings);

          case 2:
            _ref3 = _context.sent;
            tree = _ref3.tree;
            selectedId = _ref3.selectedId;

            if (!tree) {
              rcl && rcl.store && rcl.store.setter(function (self) {
                self.methodMoved301Endpoint = true;
              });
            }

            return _context.abrupt("return", {
              tree: applyNodeDefaults(tree),
              selectedId: selectedId
            });

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, this);
  }));
  return _fetchTree.apply(this, arguments);
}



/***/ }),

/***/ "i18n-react":
/*!***************************************!*\
  !*** external "window['i18n-react']" ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = window['i18n-react'];

/***/ }),

/***/ "jquery":
/*!*************************!*\
  !*** external "jQuery" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = jQuery;

/***/ }),

/***/ "mobx":
/*!***********************!*\
  !*** external "mobx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = mobx;

/***/ }),

/***/ "mobx-state-tree":
/*!********************************!*\
  !*** external "mobxStateTree" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = mobxStateTree;

/***/ }),

/***/ "rclopts":
/*!**************************!*\
  !*** external "rclOpts" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = rclOpts;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = React;

/***/ }),

/***/ "react-aiot":
/*!****************************!*\
  !*** external "ReactAIOT" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ReactAIOT;

/***/ }),

/***/ "react-dom":
/*!***************************!*\
  !*** external "ReactDOM" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ReactDOM;

/***/ })

/******/ });
//# sourceMappingURL=admin.js.map