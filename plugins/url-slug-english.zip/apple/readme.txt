=== url-slug-english ===
Contributors: zengxiaoluan
Tags: url slug translation, url slug, translation, baidu translate, youdao translate
Requires at least: 3.7
Tested up to: 4.7.2
Stable tag: 3.3
License: GPLv2 or later

url-slug-english将Permalink(固定链接)里的中文翻译为英文

== Description ==

url-slug-english将Permalink(固定链接)里的中文翻译为英文

Major features in url-slug-english include:

* 手动触发permalink翻译，使链接英文化。

== Installation ==

Upload the url-slug-english plugin to your blog, Activate it, that's done!.

== Changelog ==

= 1.1 =
*Release Date - 3 March 2017*

* 在permalink右边新增翻译按钮，手动触发翻译功能.

= 1.0 =
*Release Date - 13 February 2017*

*第一个版本