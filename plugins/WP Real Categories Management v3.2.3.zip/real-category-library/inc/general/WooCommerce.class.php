<?php
namespace MatthiasWeb\RealCategoryLibrary\general;
use MatthiasWeb\RealCategoryLibrary\base;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

/**
 * Add compatibility with WooCommerce 3.x.
 */
class WooCommerce extends base\Base {
    /**
     * Initialize WooCommerce support and check for user option.
     */
    public function init() {
        if (class_exists('WooCommerce') && get_option('woocommerce_rcl_hierarchical') === 'yes') {
            $this->applyHierarchicalAttributes();
        }
    }
    
    /**
     * Get WC attributes and add filter for each one.
     * 
     * @see See also https://support.yithemes.com/hc/en-us/articles/115000123814-Ajax-Product-filter-Attributes-are-no-longer-hierarchical-than-version-3-0-x-of-WooCommerce
     */
    private function applyHierarchicalAttributes() {
        $taxos = wc_get_attribute_taxonomies();
        foreach ($taxos as $tax) {
            $name = wc_attribute_taxonomy_name($tax->attribute_name);
            if ($name) {
                add_filter('woocommerce_taxonomy_args_' . $name, array($this, 'applyHierarchicalAttribute'));
            }
        }
    }
    
    /**
     * Set the attribute hierarchical.
     */
    public function applyHierarchicalAttribute($args) {
        $args['hierarchical'] = true;
        return $args;
    }
    
    /**
     * Add woocommerce product options.
     */
    public function woocommerce_products_general_settings($settings) {
        $settings[] = array(
			'title' => __('Real Category Management', RCL_TD),
			'type' 	=> 'title',
			'desc' 	=> '',
			'id' 	=> 'rcl_section'
        );
        
        $settings[] = array(
			'title'           => __('Product attributes', RCL_TD),
			'desc'            => __('Enable hierarchical product attributes (recommenend for > 3.x)', RCL_TD),
			'id'              => 'woocommerce_rcl_hierarchical',
			'default'         => 'no',
			'type'            => 'checkbox'
		);
		
		$settings[] = array(
			'type' 	=> 'sectionend',
			'id' 	=> 'rcl_section'
		);
        return $settings;
    }
}

?>