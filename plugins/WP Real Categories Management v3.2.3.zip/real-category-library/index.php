<?php
/**
 * @wordpress-plugin
 * Plugin Name: 	WP Real Categories Management
 * Plugin URI:		https://codecanyon.net/item/wordpress-real-category-management-custom-category-order-tree-view/13580393
 * Description: 	Organize your wordpress categories in a nice way.
 * Author:          Matthias Günter
 * Author URI:		https://matthias-web.com
 * Version: 		3.2.3
 * Text Domain:		real-category-library
 * Domain Path:		/languages
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // Avoid direct file request

/**
 * Plugin constants. This file is procedural coding style for initialization of
 * the plugin core and definition of plugin configuration.
 */
if (defined('RCL_PATH')) return;
define('RCL_FILE', __FILE__);
define('RCL_PATH', dirname(RCL_FILE));
define('RCL_INC',	trailingslashit(path_join(RCL_PATH, 'inc')));
define('RCL_MIN_PHP', '5.3.0'); // Minimum of PHP 5.3 required for autoloading and namespacing
define('RCL_MIN_WP', '4.4.0'); // Minimum of WordPress 4.4 required
define('RCL_NS', 'MatthiasWeb\\RealCategoryLibrary');
define('RCL_DB_PREFIX', 'rcl'); // The table name prefix wp_{prefix}
define('RCL_OPT_PREFIX', 'rcl'); // The option name prefix in wp_options
//define('RCL_TD', ''); This constant is defined in the core class. Use this constant in all your __() methods
//define('RCL_VERSION', ''); This constant is defined in the core class
//define('RCL_DEBUG', true); This constant should be defined in wp-config.php to enable the Base::debug() method

// Check PHP Version and print notice if minimum not reached, otherwise start the plugin core
require_once(RCL_INC . "others/" . (version_compare(phpversion(), RCL_MIN_PHP, ">=") ? "start.php" : "phpfallback.php"));