<?php
return tr_plugin_config_paths();
